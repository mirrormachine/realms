 
import re
import threading
import sys
import imaplib
import datetime
#import subprocess
import os
import random
from random import randint

######### GLOBALS   #####
global playerstr
global playerluk
global playerdex
global playercha
global playerint
global playerlvl
global playerexp
global playername
global playercash
global gotlocation
global playerhealth
global playermaxhealth
global playerinvlimit
global playerinvnumber
global playermana
global playermaxmana

global GODMODE
GODMODE = 'off'

global playerX
global playerY
global cannorth
global cansouth
global caneast
global canwest

############# IMPORTANT FUNCTION CALLS #######
def SCREENCLEAR():
    print ('    ')
    print ('    ')
    print ('    ')
    print ('    ')
    print ('    ')
    print ('    ')
    print ('    ')
    print ('    ')
    print ('    ')
    print ('    ')
    print ('    ')
    print ('    ')
    print ('    ')
    print ('    ')
    print ('    ')
    print ('    ')
    print ('    ')
    print ('    ')
    print ('    ')
    print ('    ')
    print ('    ')
    print ('    ')
    print ('    ')
    print ('    ')
    print ('    ')
    print ('    ')
    print ('    ')
    print ('    ')
    print ('    ')
    print ('    ')
    print ('    ')
    print ('    ')
    print ('    ')
    print ('    ')
    print ('    ')
    print ('    ')

def GENERATEORIGIN():
    print ('[GOD] Creating new world...')
    writfile = open('C:\\Realms\\LOC\\0 0.loc', "w")
    writfile.write('Universal Origin'+'\n')
    writfile.write('You stand in a black void. The whisper of the abyss echos in your ears. ' +'\n')
    writfile.write('an unfathomable black abyss.' +'\n')
    writfile.write('no'+'\n')
    writfile.close()

def INSPECTFUNCTION():
    INSPITEM = raw_input('['+playername+'] Inspect: ')
    if INSPITEM == '':
        INSPITEM = 'NONE'
    if INSPITEM == 'empty':
        INSPITEM = 'NONE'
    if INSPITEM in playerinventory or INSPITEM in localinventory or INSPITEM in playerwep or INSPITEM in MERCHANTITEMS or INSPITEM in playerarm or GODMODE == 'on':
        INSdata = ('C:\Realms\ITM\\'+INSPITEM+ '.itm')
        try:
            with open(INSdata) as f:
                content = f.readlines()
                content = [x.strip('\n') for x in content]
            ITEMCLASS = content[0]
            ITEMSTMOD = content[1]
            ITEMSTNUM = content[2]
            ITEMDESC = content[3]
            ITEMDAM = content[4]
            ITEMDEF = content[5]
            ITEMKEY = content[6]
            ITEMVAL = content[7]
        except:
            ITEMCLASS = 'item'
            ITEMSTMOD = 'none'
            ITEMSTNUM = 0
            ITEMDESC = '                            Invalid item.'
            ITEMDAM = 0
            ITEMDEF = 0
            ITEMKEY = 'none'
            ITEMVAL = 'null'
        try:
            if ITEMCLASS == 'item':
                print (' ')
                print ('                            |___'+str(INSPITEM)+'____|')
                print ('                     ______ |__$'+str(ITEMVAL)+'__/')
                print ('                    /               \\________')
                print ('                    |                         \\___')
                print (ITEMDESC)
                print ('                    \_____________________________/')
                print ('    ')
                print ('    ')
            if ITEMCLASS == 'key':
                print (' ')
                print ('                            |___'+str(INSPITEM)+'____|')
                print ('                     ______ |__$'+str(ITEMVAL)+'__/')
                print ('                    /               \\________/\\/\\/\\')
                print ('                    |                             |')
                print (ITEMDESC)
                print ('                    \_____________________________/')
                print ('    ')
                print ('    ')
            if ITEMCLASS == 'potion':
                print (' ')
                print (' ')
                print ('                            |___'+str(INSPITEM)+'____|')
                print ('                     ______ |__$'+str(ITEMVAL)+'_|')
                print ('                    /               |__')
                print ('                    |                 |___________')
                if ITEMSTMOD != 'none':
                    if ITEMSTMOD == 'playerstr':
                        ITEMMOD = 'Strength'
                    if ITEMSTMOD == 'skillbook':
                        ITEMMOD = ''
                    if ITEMSTMOD == 'playerluk':
                        ITEMMOD = 'Luck'
                    if ITEMSTMOD == 'playerdex':
                        ITEMMOD = 'Dexterity'
                    if ITEMSTMOD == 'playercha':
                        ITEMMOD = 'Charisma'
                    if ITEMSTMOD == 'playerint':
                        ITEMMOD = 'Intelligence'
                    if ITEMSTMOD == 'playercash':
                        ITEMMOD = 'Wealth'
                    if ITEMSTMOD == 'playerlvl':
                        ITEMMOD = 'Level'
                    if ITEMSTMOD == 'playermaxhealth':
                        ITEMMOD = 'Max Health'
                    if ITEMSTMOD == 'playerhealth':
                        ITEMMOD = 'Health'
                    if ITEMSTMOD == 'bagexpand':
                        ITEMMOD = 'Capacity'
                    if ITEMSTMOD == 'playermana':
                        ITEMMOD = 'Mana'
                    if ITEMSTMOD == 'playermaxmana':
                        ITEMMOD = 'Max Mana'
                    if ITEMSTMOD == 'teleport':
                        ITEMMOD = 'Teleport'
                                
                    print (ITEMDESC)
                    print ('                    \_____________________________/')
                    print ('                            '+str(ITEMMOD)+' + '+str(ITEMSTNUM))
                    print ('    ')
                    print ('    ')
                else:
                    print (ITEMDESC)
                    print ('                    \_____________________________/')
                    print ('    ')
                    print ('    ')
            if ITEMCLASS == 'weapon':
                print (' ')
                print (' ')
                print ('                            |___'+str(INSPITEM)+'____|')
                print ('                            |__ATK:'+str(ITEMDAM)+'_|')
                print ('                     ______ |__$'+str(ITEMVAL)+'_|')
                print ('                    /               |__')
                print ('                    |                 |___________')
                if ITEMSTMOD != 'none':
                    if ITEMSTMOD == 'souledge':
                        ITEMMOD = 'Damage per Kill'
                    if ITEMSTMOD == 'playerstr':
                        ITEMMOD = 'Strength'
                    if ITEMSTMOD == 'playerluk':
                        ITEMMOD = 'Luck'
                    if ITEMSTMOD == 'playerdex':
                        ITEMMOD = 'Dexterity'
                    if ITEMSTMOD == 'playercha':
                        ITEMMOD = 'Charisma'
                    if ITEMSTMOD == 'playerint':
                        ITEMMOD = 'Intelligence'
                    if ITEMSTMOD == 'playercash':
                        ITEMMOD = 'Wealth'
                    if ITEMSTMOD == 'playerlvl':
                        ITEMMOD = 'Level'
                    if ITEMSTMOD == 'playermaxhealth':
                        ITEMMOD = 'Max Health'
                    if ITEMSTMOD == 'playerhealth':
                        ITEMMOD = 'Health'
                    if ITEMSTMOD == 'pierce':
                        ITEMMOD = 'Pierce Damage'
                    if ITEMSTMOD == 'healthleech':
                        ITEMMOD = 'Health Leech'
                    if ITEMSTMOD == 'manaleech':
                        ITEMMOD = 'Mana Leech'
                    print (ITEMDESC)
                    print ('                    \_____________________________/')
                    print ('                            '+str(ITEMMOD)+' + '+str(ITEMSTNUM))
                    print ('    ')
                    print ('    ')
                else:
                    print (ITEMDESC)
                    print ('                    \_____________________________/')
                    print ('    ')
                    print ('    ')
            if ITEMCLASS == 'armor':
                print (' ')
                print (' ')
                print ('                            |___'+str(INSPITEM)+'____|')
                print ('                            |__DEF: '+str(ITEMDEF)+'_|')
                print ('                     ______ |__$'+str(ITEMVAL)+'_|')
                print ('                    /               |__')
                print ('                    |                 |___________')
                if ITEMSTMOD != 'none':
                    if ITEMSTMOD == 'playerstr':
                        ITEMMOD = 'Strength'
                    if ITEMSTMOD == 'playerluk':
                        ITEMMOD = 'Luck'
                    if ITEMSTMOD == 'playerdex':
                        ITEMMOD = 'Dexterity'
                    if ITEMSTMOD == 'playercha':
                        ITEMMOD = 'Charisma'
                    if ITEMSTMOD == 'playerint':
                        ITEMMOD = 'Intelligence'
                    if ITEMSTMOD == 'playercash':
                        ITEMMOD = 'Wealth'
                    if ITEMSTMOD == 'playerlvl':
                        ITEMMOD = 'Level'
                    if ITEMSTMOD == 'playermaxmana':
                        ITEMMOD = 'Max Mana'
                    if ITEMSTMOD == 'playermaxhealth':
                        ITEMMOD = 'Max Health'
                    if ITEMSTMOD == 'playerhealth':
                        ITEMMOD = 'Health'
                    print (ITEMDESC)
                    print ('                    \_____________________________/')
                    print ('                            '+str(ITEMMOD)+' + '+str(ITEMSTNUM))
                    print ('    ')
                    print ('    ')
                else:
                    print (ITEMDESC)
                    print ('                    \_____________________________/')
                    print ('    ')
                    print ('    ')
        except:
            print ('ERROR: Undefined item class.')
    else:
        print ('['+playername+'] No such item nearby.')
def LOCATIONCHECK():
    LOCdata = ('C:\Realms\LOC\\' + str(playerX) + ' ' + str(playerY) + '.loc' )
    with open(LOCdata) as f:
        content = f.readlines()
        content = [x.strip('\n') for x in content]
    global LOCname
    global LOCdesc
    LOCname = content[0]
    LOCdesc = content[1]

######### chECK FOR STAT CHECKS
    try:
        open('C:\\Realms\\INV\\'+str(playerX)+' '+str(playerY)+'.chk')
        CHKdata = ('C:\\Realms\\INV\\'+str(playerX)+' '+str(playerY)+'.chk')
        with open(CHKdata) as f:
            event = f.readlines()
            event = [x.strip('\n') for x in event]
        STAT = event[0]
        STATNUM = event[1]
        EVENT1 = event[2]
        EVENT2 = event[3]
        REPEATPASS = event[4]
        REPEATFAIL = event[5]
        ### str, luk, dex, int, cha
        if STAT == 'lvl':
            COMPARE = int(playerlvl)
        if STAT == 'str':
            COMPARE = int(playerstr)
        if STAT == 'luk':
            COMPARE = int(playerluk)
        if STAT == 'dex':
            COMPARE = int(playerdex)
        if STAT == 'int':
            COMPARE = int(playerint)
        if STAT == 'cha':
            COMPARE = int(playercha)
        if int(COMPARE) >= int(STATNUM):
            writfile = open('C:\\Realms\\INV\\'+str(playerX)+' '+str(playerY)+'.eve', "a")
            writfile.write(EVENT1+'\n')
            writfile.close()
            if REPEATPASS == 'no':
                os.remove('C:\\Realms\\INV\\'+str(playerX)+' '+str(playerY)+'.chk')
        else:
            if EVENT2 != 'none':
                writfile = open('C:\\Realms\\INV\\'+str(playerX)+' '+str(playerY)+'.eve', "a")
                writfile.write(EVENT2+'\n')
                writfile.close()
                if REPEATFAIL == 'no':
                    os.remove('C:\\Realms\\INV\\'+str(playerX)+' '+str(playerY)+'.chk')
            else:
                pass
    except:
        pass
 ######### chECK FOR BEFORE EVENTS       
    try:
        open('C:\\Realms\\INV\\'+str(playerX)+' '+str(playerY)+'.eve')
        EVEparse = ('C:\\Realms\\INV\\'+str(playerX)+' '+str(playerY)+'.eve')
        with open(EVEparse) as f:
            events = f.readlines()
            events = [x.strip('\n') for x in events]
        CURRENTEVENT = events[0]
        try:
        
            if events[1] != '':
                COMBO = 'yes'
        except:
            COMBO = 'no'
        EVTdata = ('C:\\Realms\\EVT\\'+str(CURRENTEVENT)+'.eve')
        with open(EVTdata) as f:
            event = f.readlines()
            event = [x.strip('\n') for x in event]
        EVTDESC = event[0]
        EVTTAG = event[1]
        EVTSTAT = event[2]
        EVTREP = event[3]
        EVTCOORDS = event[4]
        EVTTIME = event[5]
        if EVTTIME == 'before':
            if EVTREP == 'no':
                events.remove(CURRENTEVENT)
                open('C:\\Realms\\INV\\'+str(playerX)+' '+str(playerY)+'.eve', "w").close()
                with open('C:\\Realms\\INV\\'+str(playerX)+' '+str(playerY)+'.eve', "w") as f:
                    for s in events:
                        f.write(s + '\n')
            if EVTCOORDS == 'currentarea':
                EVTCOORDS = (str(playerX)+' '+str(playerY))
                
            print EVTDESC
            
            if EVTTAG == 'dropitem':
                writfile = open('C:\\realms\\INV\\'+EVTCOORDS+'.inv', "a")
                writfile.write(EVTSTAT+'\n')
                writfile.close()
    
            if EVTTAG == 'spawnenemy':
                writfile = open('C:\\realms\\INV\\'+EVTCOORDS+'.enm', "a")
                writfile.write(EVTSTAT+'\n')
                writfile.close()
            
            if EVTTAG == 'spawnevent':
                writfile = open('C:\\realms\\INV\\'+EVTCOORDS+'.eve', "a")
                writfile.write(EVTSTAT+'\n')
                writfile.close()
                
            if EVTTAG == 'spawncompanion':
                writfile = open('C:\\realms\\INV\\'+EVTCOORDS+'.cmp', "a")
                writfile.write(EVTSTAT+'\n')
                writfile.close()               

            if EVTTAG == 'heal':
                global playerhealth
                playerhealth = int(playerhealth)+int(EVTSTAT)
                global playermana
                playermana = int(playermana)+int(EVTSTAT)
            if EVTTAG == 'hurt':
                global playerhealth
                playerhealth = int(playerhealth)-int(EVTSTAT)
            if EVTTAG == 'teleport':
                EVTCOORDS = EVTCOORDS.split(' ')
                global playerX
                playerX = EVTCOORDS[0]
                global playerY
                playerY = EVTCOORDS[1]
                LOCdata = ('C:\Realms\LOC\\' + str(playerX) + ' ' + str(playerY) + '.loc' )
                with open(LOCdata) as f:
                    content = f.readlines()
                    content = [x.strip('\n') for x in content]
                global LOCname
                global LOCdesc
                LOCname = content[0]
                LOCdesc = content[1]


    except:

        pass

################
    print (' ')
    print ('                        -[  '+str(LOCname)+'  ]-')
    print (' ')
    print (LOCdesc)
##########CHECK FOR EVENTS#########
    try:
        open('C:\\Realms\\INV\\'+str(playerX)+' '+str(playerY)+'.eve')
        EVEparse2 = ('C:\\Realms\\INV\\'+str(playerX)+' '+str(playerY)+'.eve')
        with open(EVEparse2) as f:
            events = f.readlines()
            events = [x.strip('\n') for x in events]
        CURRENTEVENT = events[0]
        try:
            if COMBO == 'yes':
                CURRENTEVENT = events[1]
                pass
            else:
                CURRENTEVENT = events[0]
                pass
        except:
            pass
        EVTdata = ('C:\\Realms\\EVT\\'+str(CURRENTEVENT)+'.eve')
        with open(EVTdata) as f:
            event = f.readlines()
            event = [x.strip('\n') for x in event]
        EVTDESC = event[0]
        EVTTAG = event[1]
        EVTSTAT = event[2]
        EVTREP = event[3]
        EVTCOORDS = event[4]
        EVTTIME = event[5]
        if EVTTIME == 'after':
            if EVTCOORDS == 'currentarea':
                EVTCOORDS = (str(playerX)+' '+str(playerY))
            print EVTDESC
            if EVTTAG == 'dropitem':
                writfile = open('C:\\realms\\INV\\'+EVTCOORDS+'.inv', "a")
                writfile.write(EVTSTAT+'\n')
                writfile.close()
                
            if EVTTAG == 'spawncompanion':
                writfile = open('C:\\realms\\INV\\'+EVTCOORDS+'.cmp', "a")
                writfile.write(EVTSTAT+'\n')
                writfile.close()               

            if EVTTAG == 'spawnenemy':
                writfile = open('C:\\realms\\INV\\'+EVTCOORDS+'.enm', "a")
                writfile.write(EVTSTAT+'\n')
                writfile.close()
            
            if EVTTAG == 'spawnevent':
                writfile = open('C:\\realms\\INV\\'+EVTCOORDS+'.eve', "a")
                writfile.write(EVTSTAT+'\n')
                writfile.close()
            
            if EVTTAG == 'heal':
                global playerhealth
                playerhealth = int(playerhealth)+int(EVTSTAT)
                global playermana
                playermana = int(playermana)+int(EVTSTAT)
            if EVTTAG == 'hurt':
                global playerhealth
                playerhealth = int(playerhealth)-int(EVTSTAT)
            if EVTTAG == 'teleport':
                print ('ERROR: Teleport event tag can only be used on before events')
            if EVTREP == 'no':
                events.remove(CURRENTEVENT)
                open('C:\\Realms\\INV\\'+str(playerX)+' '+str(playerY)+'.eve', "w").close()
                with open('C:\\Realms\\INV\\'+str(playerX)+' '+str(playerY)+'.eve', "w") as f:
                    for s in events:
                        f.write(s + '\n')

    except:
    
        pass
#### GOSSIP CHECK #####
    try:
        open('C:\\Realms\\INV\\'+str(playerX)+' '+str(playerY)+'.gos')
        LISTTOTAL = 0
        TALKdata = ('C:\\Realms\\INV\\'+str(playerX)+' '+str(playerY)+'.gos')
        with open(TALKdata) as f:
            content = f.readlines()
            content = [x.strip('\n') for x in content]
            for x in content:
                LISTTOTAL = int(LISTTOTAL) + 1
        GOSSIPTEXT = randint(1,int(LISTTOTAL))
        GOSSIPTEXT = int(GOSSIPTEXT) - 1
        print content[GOSSIPTEXT]

    except:
        pass
#### COMPANION GOSSIP CHECK #####
    if playercomp != 'none':
        WILLTALK = randint(1,100)
        if WILLTALK <= 20:
            try:
                open('C:\\Realms\\NPC\\'+str(playercomp)+'.gos')
                LISTTOTAL = 0
                compTALKdata = ('C:\\Realms\\NPC\\'+str(playercomp)+'.gos')
                with open(compTALKdata) as f:
                    content = f.readlines()
                    content = [x.strip('\n') for x in content]
                    for x in content:
                        LISTTOTAL = int(LISTTOTAL) + 1
                GOSSIPTEXT = randint(1,int(LISTTOTAL))
                GOSSIPTEXT = int(GOSSIPTEXT) - 1
                print content[GOSSIPTEXT]     
            except:
                print ('[GOD] ERROR READING COMPANION DATA FOR '+str(playercomp))
                pass
##### COMPANION IDLE CHECK ##################
    try:
        open('C:\\Realms\\INV\\'+str(playerX)+' '+str(playerY)+'.cmp')
        ENMparse = ('C:\\Realms\\INV\\'+str(playerX)+' '+str(playerY)+'.cmp')
        with open(ENMparse) as f:
            enemy = f.readlines()
            enemy = [x.strip('\n') for x in enemy]
        TARGET = enemy[0]
        ENMdata = ('C:\\Realms\\NPC\\'+str(TARGET)+'.npc')
        with open(ENMdata) as f:
            enemy = f.readlines()
            enemy = [x.strip('\n') for x in enemy]
        compidle = enemy[3]
        comphire = enemy[4]
        print compidle
    except:
        pass
##########CHECK FOR ENEMIES#########
    try:
        open('C:\\Realms\\INV\\'+str(playerX)+' '+str(playerY)+'.enm')
        ENMparse = ('C:\\Realms\\INV\\'+str(playerX)+' '+str(playerY)+'.enm')
        with open(ENMparse) as f:
            enemy = f.readlines()
            enemy = [x.strip('\n') for x in enemy]
        TARGET = enemy[0]
        ENMdata = ('C:\\Realms\\ENM\\'+str(TARGET)+'.enm')
        with open(ENMdata) as f:
            enemy = f.readlines()
            enemy = [x.strip('\n') for x in enemy]
        ENMDESC = enemy[0]
        print ENMDESC

    except:

        pass

    print ('    ')
    
         
#######################BANNER MODULE####################################

SCREENCLEAR()
print ('    _|_|_|    _|_|_|_|    _|_|    _|        _|      _|    _|_|_|  ')
print ('    _|    _|  _|        _|    _|  _|        _|_|  _|_|  _|        ')
print ('    _|_|_|    _|_|_|    _|_|_|_|  _|        _|  _|  _|    _|_|    ')
print ('    _|    _|  _|        _|    _|  _|        _|      _|        _|  ')
print ('    _|    _|  _|_|_|_|  _|    _|  _|_|_|_|  _|      _|  _|_|_|    ')
print (' ')
print ('                                                            v 1.3')
print ('   _|_|_|_|_|_|_|_|_|_|_|_|_|_|_|_|_|_|_|_|_|_|_|_|_|_|_|_|_|_|_|')
print (' ')
print (' ')
print ('      new    =   Create a new character and begin playing Realms')
print ('      load   =   Load a character')
print ('      quit   =   Close the application')
print ('      realm  =   Mount a different world')
print ('      help   =   Always works. When in doubt!')
print ('    ')
print ('    ')
print ('    ')
print ('    ')
print ('    ')
print ('    ')
print ('    ')


def BoolFalse():
    global BoolNet
    BoolNet = False

def BoolTrue():
    global BoolNet
    BoolNet = True

BoolFalse()

while BoolNet == False:
    
   BOOT = raw_input('[!]: ')
   if BOOT == 'help':
       print (' ')
       print ('      new    =   Create a new character and begin playing Realms')
       print ('      load   =   Load a character')
       print ('      quit   =   Exit the Realms application')
       print ('      realm  =   Mount a new world')
       print ('    ')
   if BOOT == 'realm':
       os.system('dir c:\\Realms\\Worlds')
       WORLDNAME = raw_input('[?] Story: ')
       os.system('del /s /q c:\\Realms\\INV')
       os.system('del /s /q c:\\Realms\\ITM')
       os.system('del /s /q c:\\Realms\\LOC')
       os.system('del /s /q c:\\Realms\\NPC')
       os.system('del /s /q c:\\Realms\\SAV')
       os.system('del /s /q c:\\Realms\\ENM')
       os.system('del /s /q c:\\Realms\\EVT')  
       os.system ('copy C:\\Realms\\Worlds\\'+WORLDNAME+'\\INV C:\\Realms\\INV ')
       os.system ('copy C:\\Realms\\Worlds\\'+WORLDNAME+'\\ITM C:\\Realms\\ITM ')
       os.system ('copy C:\\Realms\\Worlds\\'+WORLDNAME+'\\LOC C:\\Realms\\LOC ')
       os.system ('copy C:\\Realms\\Worlds\\'+WORLDNAME+'\\NPC C:\\Realms\\NPC ')
       os.system ('copy C:\\Realms\\Worlds\\'+WORLDNAME+'\\SAV C:\\Realms\\SAV ')
       os.system ('copy C:\\Realms\\Worlds\\'+WORLDNAME+'\\ENM C:\\Realms\\ENM ')
       os.system ('copy C:\\Realms\\Worlds\\'+WORLDNAME+'\\EVT C:\\Realms\\EVT ')
   if BOOT == 'new':

####          CHARACTER GEN          ###

      
      try:
          open('C:\\realms\\LOC\\0 0.loc')
      except:
          GENERATEORIGIN()

      playername= raw_input('[?] Name: ')
      SCREENCLEAR()
      playerstr = 1
      playerluk = 1
      playerdex = 1
      playercha = 1
      playerint = 1
      
      playerlvl = 1
      playerexp = 0

      playercash = 0
      playerX = 0
      playerY = 0
      gotlocation = 0

      playerhealth = 10
      playermaxhealth = 10
      playerdam = 1
      playerdef = 1
      playerinvlimit = 5
      playerinvnumber = 0
      godcommand = 'god'
      playermana = 0
      playermaxmana = 0
      playerwep = 'empty'
      playerarm = 'empty'
      playercomp = 'none'


      writfile = open('C:\\Realms\\SAV\\'+playername+'.sav', "a")
      writfile.write(str(playername) +'\n')
      writfile.write(str(playerstr) +'\n')
      writfile.write(str(playerluk) +'\n')
      writfile.write(str(playerdex) +'\n')
      writfile.write(str(playercha) +'\n')
      writfile.write(str(playerint) +'\n')
      writfile.write(str(playerlvl) +'\n')
      writfile.write(str(playerexp) +'\n')
      writfile.write(str(playercash) +'\n')
      writfile.write(str(playerX) +'\n')
      writfile.write(str(playerY) +'\n')
      writfile.write(str(playerhealth) +'\n')
      writfile.write(str(playermaxhealth) +'\n')
      writfile.write(str(playerdam) +'\n')
      writfile.write(str(playerdef) +'\n')
      writfile.write(str(playerinvlimit) +'\n')
      writfile.write(str(playerinvnumber) +'\n')
      writfile.write(str(godcommand) +'\n')
      writfile.write(str(playermana) +'\n')
      writfile.write(str(playermaxmana) +'\n')
      writfile.write(str(playerwep) +'\n')
      writfile.write(str(playerarm) +'\n')
      writfile.write(str(playercomp) +'\n')
      writfile.close()

      writfile = open('C:\\Realms\\INV\\'+playername+'.inv', "a")
      writfile.close()
      writfile = open('C:\\Realms\\INV\\'+playername+'.skl', "a")
      writfile.close()
      writfile.close()

      
      with open('c:\\realms\\inv\\'+str(playername)+'.inv') as f:
              playerinventory = f.read().split('\n')
      with open('c:\\realms\\inv\\'+str(playername)+'.skl') as f:
              playerskills = f.read().split('\n')
              
      BoolTrue()
      
          
   if BOOT == ('quit'):
      sys.exit(1)
      
   if BOOT == ('load'):

      try:
          SAVdata = ('C:\Realms\SAV\\'+raw_input('[?] Name: ') + '.sav')
          with open(SAVdata) as f:
              content = f.readlines()
              content = [x.strip('\n') for x in content]
          SCREENCLEAR()
          playername = content[0]
          playerstr = content[1]
          playerluk = content[2]
          playerdex = content[3]
          playercha = content[4]
          playerint = content[5]
          playerlvl = content[6]
          playerexp = content[7]
          playercash = content[8]
          playerX = content[9]
          playerY = content[10]
          playerhealth = content[11]
          playermaxhealth = content[12]
          playerdam = content[13]
          playerdef = content[14]
          playerinvlimit = content[15]
          playerinvnumber = content[16]
          godcommand = content[17]
          playermana = content[18]
          playermaxmana = content[19]
          playerwep = content[20]
          playerarm = content[21]
          playercomp = content[22]
          

########INV INIT####@
          with open('c:\\realms\\inv\\'+str(playername)+'.inv') as f:
              playerinventory = f.read().split('\n')
          
          with open('c:\\realms\\inv\\'+str(playername)+'.skl') as f:
              playerskills = f.read().split('\n')
          if playercomp != 'none':
              with open('c:\\realms\\NPC\\'+str(playercomp)+'.inv') as f:
                  compinventory = f.read().split('\n')
    
#####################
          BoolTrue()
          gotlocation = 0
          
      except:
          print ('[!] No character by that name.')

##########################      GAME LOOP   ###############################
   while BoolNet == True:


#########   LOCATION CHECK  AND MERCHANT CHECK #############
        
        FIGHTSKIP = 0        
        if (gotlocation == 0):
            LOCATIONCHECK()
            gotlocation = 1
            try:
                with open('c:\\realms\\inv\\'+str(playerX)+' '+str(playerY)+'.mch') as f:
                    content = f.read().split('\n')
                MERCHANTDESC = content[0]
                MERCHANTITEMS = [content[1],content[2],content[3],content[4],content[5],content[6],content[7],content[8],content[9],content[10]]
                try:
                    MERCHANTITEMS.remove('0')
                    MERCHANTITEMS.remove('0')
                    MERCHANTITEMS.remove('0')
                    MERCHANTITEMS.remove('0')
                    MERCHANTITEMS.remove('0')
                    MERCHANTITEMS.remove('0')
                    MERCHANTITEMS.remove('0')
                    MERCHANTITEMS.remove('0')
                    MERCHANTITEMS.remove('0')
                    MERCHANTITEMS.remove('0')
                except:
                    pass
                global cantrade
                cantrade = 1
                    
            except:
                global cantrade
                cantrade = 0
                MERCHANTITEMS = []
            try:
                with open('c:\\realms\\inv\\'+str(playerX)+' '+str(playerY)+'.inv') as f:
                    localinventory = f.read().split('\n')
                try:
                    localinventory.remove('')
                    localinventory.remove('')
                    localinventory.remove('')
                    localinventory.remove('')
                    localinventory.remove('')
                    localinventory.remove('')
                    localinventory.remove('')
                    localinventory.remove('')
                except:
                    pass
            except:
                writfile = open('c:\\realms\\inv\\'+str(playerX)+' '+str(playerY)+'.inv', "a")
                writfile.close()
                with open('c:\\realms\\inv\\'+str(playerX)+' '+str(playerY)+'.inv') as f:
                    localinventory = f.read().split('\n')
                    
########  PLAYER LOOP  #######
        NEXTLEVEL = (int(playerlvl) * int(playerlvl))
        NEXTLEVEL = (int(NEXTLEVEL)*25)

        command = raw_input("[" + playername + "]: ").strip('n')
        if command == 'fuck you':
            print ('[GOD] "That was uncalled for."')
            
        if command == 'help':
            
            FIGHTSKIP = 1
            print (' ')
            print (' ')
            print (' ')
            print ('           [st] stats : An overview of your attributes')
            print ('              [b] bag : View what you are carrying')
            print ('              [u] use : Use an item in your inventory')
            print ('          [se] search : Check the area for items of note')
            print ('          [i] inspect : Get a close look at an item nearby')
            print ('             [g] grab : Pick up and store an item. Try \'all\'')
            print ('             [d] drop : Drop an item at your feet')
            print ('             [t] toss : Throw an item away')
            print ('          [sk] skills : view your combat skills')
            print ('           [tr] trade : Buy and sell, if merchants are nearby')
            print ('                 ally : Join forces with an ally.')
            print ('                 part : Part ways with an ally.')
            print ('         [cb] compbag : View companion inventory')
            print ('                 give : Give your companion an item')
            print ('                 take : Take an item from your companion')
            print ('           [l] locale : View local area information')
            print ('              [m] map : View surrounding area information')
            print ('             [w] walk : Move to a different area')
            print ('           [eq] equip : Equip a weapon from your bag')
            print ('       [uneq] unequip : Put something away')
            print ('                 save : Save your progress')
            print (' ')
            print (' ')
            print (' ')
            command = ('      ')

    
        if command == 'sk':
            command = 'skills'
        if command == 'skills':
            FIGHTSKIP = 1
            try:
                playerskills.remove('')
                playerskills.remove('')
                playerskills.remove('')
                playerskills.remove('')
                playerskills.remove('')
                playerskills.remove('')
                playerskills.remove('')
                playerskills.remove('')
                playerskills.remove('')
                playerskills.remove('')

            except:
                pass
            if playerskills != []:
                print (' ')
                for y in playerskills:
                    INSdata = ('C:\Realms\ITM\\'+str(y)+ '.skl')
                    with open(INSdata) as f:
                        content = f.readlines()
                        content = [x.strip('\n') for x in content]
                    SKILLDESC = content[12]

                    print (' ')
                    print (' ['+str(y)+'] - '+str(content[12]))
                print (' ')
                print (' ')
            else:
                print ('['+playername+'] I don\'t know any combat skills.')

        if command == 'part':
            if playercomp != 'none':
                ENEMC = (str(playerX)+' '+str(playerY))
                ENEM = playercomp
                open('C:\\Realms\\NPC\\'+playercomp+'.inv', "w").close()
                with open('C:\\Realms\\NPC\\'+playercomp+'.inv', "w") as f:
                    for s in compinventory:
                        f.write(s + '\n') 
                try:
                    open('C:\\realms\\INV\\'+ENEMC+'.cmp')
                    writfile = open('C:\\realms\\INV\\'+ENEMC+'.cmp', "a")
                    writfile.write(ENEM+'\n')
                    writfile.close()
                    print ('['+playername+'] Goodbye, '+str(ENEM))
                    playercomp = 'none'
                except:
                    open('C:\\realms\\INV\\'+ENEMC+'.cmp', "w").close()
                    open('C:\\realms\\INV\\'+ENEMC+'.cmp')
                    writfile = open('C:\\realms\\INV\\'+ENEMC+'.cmp', "a")
                    writfile.write(ENEM+'\n')
                    writfile.close()
                    print ('['+playername+'] Goodbye, '+str(ENEM))
                    playercomp = 'none'
            else:
                print ('['+playername+'] I don\'t have a companion.')


        if command == 'ally':
            if playercomp == 'none':
                try:
                    open('C:\\Realms\\INV\\'+str(playerX)+' '+str(playerY)+'.cmp')
                    ENMparse = ('C:\\Realms\\INV\\'+str(playerX)+' '+str(playerY)+'.cmp')
                    with open(ENMparse) as f:
                        enemy = f.readlines()
                        enemy = [x.strip('\n') for x in enemy]
                    TARGET = enemy[0]
                    ENMdata = ('C:\\Realms\\NPC\\'+str(TARGET)+'.npc')
                    with open(ENMdata) as f:
                        enemy = f.readlines()
                        enemy = [x.strip('\n') for x in enemy]
                    comphire = enemy[4]
                    print comphire
                    with open('c:\\realms\\NPC\\'+str(TARGET)+'.inv') as f:
                        compinventory = f.read().split('\n')
                    playercomp = TARGET
                    os.remove('C:\\Realms\\INV\\'+str(playerX)+' '+str(playerY)+'.cmp')
                except:
                    print ('['+playername+'] No allies nearby.')
                    
            else:
                print ('['+playername+'] I already have a companion.')


        if command == 'tr':
            command = 'trade'
        if command == 'trade':
            if cantrade == 1:
                print (' ')
                def TRADEON():
                    global frootNet4
                    frootNet4 = False
                def TRADEOFF():
                    global frootNet4
                    frootNet4 = True
                TRADEON()
                print MERCHANTDESC
                print (' ')
                print(' ')
                SKIPVAL = 0
                while frootNet4 == False:
                    if SKIPVAL == 0:
                        print ('[TRADE] You have $'+str(playercash))
                        SKIPVAL = 1
                    tradecmd = raw_input('[TRADE]: ')
                    if tradecmd == 'help':
                        SKIPVAL = 1
                        print (' ')
                        print (' ')
                        print ('        [br] browse: Check out what\'s for sale')
                        print ('        [i] inspect: Get a closer look at an item')
                        print ('            [b] bag: View your inventory')
                        print ('                buy: Purchase an item')
                        print ('               sell: Sell an item. Try \'all\'.')
                        print ('          [l] leave: exit the shop')
                        print (' ')
                        print (' ')
                    if tradecmd == 'br':
                        tradecmd = 'browse'
                    if tradecmd == 'browse':
                        print (' ')
                        for y in MERCHANTITEMS:
                            INSdata = ('C:\Realms\ITM\\'+str(y)+ '.itm')
                            with open(INSdata) as f:
                                content = f.readlines()
                                content = [x.strip('\n') for x in content]
                            ITEMCLASS = content[0]
                            ITEMSTMOD = content[1]
                            ITEMSTNUM = content[2]
                            ITEMDESC = content[3]
                            ITEMDAM = content[4]
                            ITEMDEF = content[5]
                            ITEMKEY = content[6]
                            ITEMVAL = content[7]
                            print ('            ____________')
                            print ('        -=[ '+str(y))
                            print ('            $'+str(ITEMVAL))
                        print (' ')
                    if tradecmd == 'b':
                         tradecmd = 'bag'
                    if tradecmd == 'bag':
                        print ('[TRADE] You have $'+str(playercash))
                        FIGHTSKIP = 1
                        try:
                            playerinventory.remove('')
                            playerinventory.remove('')
                            playerinventory.remove('')
                            playerinventory.remove('')
                            playerinventory.remove('')
                            playerinventory.remove('')
                            playerinventory.remove('')
                            playerinventory.remove('')
                            playerinventory.remove('')
                            playerinventory.remove('')
                            playerinventory.remove('')
                            playerinventory.remove('')
                            playerinventory.remove('')
                            playerinventory.remove('')
                            playerinventory.remove('')
                            playerinventory.remove('')
                            playerinventory.remove('')
                            playerinventory.remove('')
                            playerinventory.remove('')
                            playerinventory.remove('')
    
                        except:
                            pass
                            if playerinventory != []:
############################CUSTOMINVPARSE
                            
                                print (' ')
                                for y in playerinventory:
                                    INSdata = ('C:\Realms\ITM\\'+str(y)+ '.itm')
                                    with open(INSdata) as f:
                                        content = f.readlines()
                                        content = [x.strip('\n') for x in content]
                                    ITEMCLASS = content[0]
                                    ITEMSTMOD = content[1]
                                    ITEMSTNUM = content[2]
                                    ITEMDESC = content[3]
                                    ITEMDAM = content[4]
                                    ITEMDEF = content[5]
                                    ITEMKEY = content[6]
                                    ITEMVAL = content[7]
                                    print ('            ____________')
                                    print ('        -=[ '+str(y))
                                    print ('            $'+str(ITEMVAL))
                                print (' ')
########################################
                        else:
                            print ('['+playername+'] My bag is empty.')

                    if tradecmd == 'i':
                        tradecmd = 'inspect'
                    if tradecmd == 'inspect':
                        SKIPVAL = 1
                        INSPECTFUNCTION()
                        
                    if tradecmd == 'buy':
                        if int(playerinvnumber) < int(playerinvlimit):
                            SKIPVAL = 0
                            print ('[TRADE] What are you buying?')
                            BUYITEM = raw_input('[TRADE]Item: ')
                            BUYdata = ('C:\Realms\ITM\\'+BUYITEM+ '.itm')
                            try:
                                open(BUYdata)
                                with open(BUYdata) as f:
                                    content = f.readlines()
                                    content = [x.strip('\n') for x in content]
                                ITEMCLASS = content[0]
                                ITEMSTMOD = content[1]
                                ITEMSTNUM = content[2]
                                ITEMDESC = content[3]
                                ITEMDAM = content[4]
                                ITEMDEF = content[5]
                                ITEMKEY = content[6]
                                ITEMVAL = content[7]
                                ITEMVAL = int(ITEMVAL)
                                playercash = int(playercash)    
                                if ITEMVAL <= playercash:
                                    playercash = int(playercash) - int(ITEMVAL)
                                    playerinventory.insert(0, BUYITEM)
                                    playerinvnumber = int(playerinvnumber)+1
                                    print ('[TRADE] Enjoy your '+str(BUYITEM))
                                else:
                                    print ('[TRADE] You can\'t afford that.')
                            except:
                                print ('[TRADE] I don\'t have one of those.')
                                SKIPVAL = 1
                        else:
                            print ('['+playername+'] My bag is already full.')
                            


                    if tradecmd == 'sell':
                        SKIPVAL = 0
                        print ('[TRADE] What are you selling?')
                        BUYITEM = raw_input('[TRADE]Item: ')
                        if BUYITEM == 'all':
                            print (' ')
                            try:
                                playerinventory.remove('')
                                playerinventory.remove('')
                                playerinventory.remove('')
                                playerinventory.remove('')
                                playerinventory.remove('')
                                playerinventory.remove('')
                                playerinventory.remove('')
                                playerinventory.remove('')
                            except:
                                pass
                            while playerinventory != []:
                                for y in playerinventory:
                                    BUYdata = ('C:\Realms\ITM\\' +str(y)+ '.itm')
                                    with open(BUYdata) as f:
                                        content = f.readlines()
                                        content = [x.strip('\n') for x in content]
                                    ITEMCLASS = content[0]
                                    ITEMSTMOD = content[1]
                                    ITEMSTNUM = content[2]
                                    ITEMDESC = content[3]
                                    ITEMDAM = content[4]
                                    ITEMDEF = content[5]
                                    ITEMKEY = content[6]
                                    ITEMVAL = content[7]
                                    ITEMVAL = int(ITEMVAL)
                                    playercash = int(playercash)
                                    CHAMOD = int(playercha)*.1 
                                    NEWVALUE = ITEMVAL * CHAMOD
                                    if int(NEWVALUE) > int(ITEMVAL):
                                        NEWVALUE = ITEMVAL
                                    playerinvnumber = int(playerinvnumber)-1
                                    playercash = int(playercash) + int(NEWVALUE)
                                    playerinventory.remove(y)
                                    print ('[TRADE] I\'ll take the '+str(y)+' for $'+str(NEWVALUE)+'.')
                            print ('[TRADE] Always a pleasure.')
                            print (' ')
                        else:
                            BUYdata = ('C:\Realms\ITM\\'+BUYITEM+ '.itm')
                            try:
                                open(BUYdata)
                                with open(BUYdata) as f:
                                    content = f.readlines()
                                    content = [x.strip('\n') for x in content]
                                ITEMCLASS = content[0]
                                ITEMSTMOD = content[1]
                                ITEMSTNUM = content[2]
                                ITEMDESC = content[3]
                                ITEMDAM = content[4]
                                ITEMDEF = content[5]
                                ITEMKEY = content[6]
                                ITEMVAL = content[7]
                                ITEMVAL = int(ITEMVAL)
                                playercash = int(playercash)    
                                if BUYITEM in playerinventory:
                                    CHAMOD = int(playercha)*.1 
                                    NEWVALUE = ITEMVAL * CHAMOD
                                    if int(NEWVALUE) > int(ITEMVAL):
                                        NEWVALUE = ITEMVAL
                                    playerinvnumber = int(playerinvnumber)-1
                                    playercash = int(playercash) + int(NEWVALUE)
                                    playerinventory.remove(BUYITEM)
                                    print ('[TRADE] Pleasure doing business with you. ')
                            except:
                                print ('[TRADE] That isn\'t a real thing. ')
                                SKIPVAL = 1
                       
                    if tradecmd == 'l':
                        tradecmd = 'leave'
                    if tradecmd == 'leave':
                        print ('[TRADE] "Come back anytime." ')
                        print (' ')
                        TRADEOFF()

            if cantrade == 0:
                print ('['+playername+'] There\'s nobody to trade with here.')
        if command == 'm':
            command = 'map'
        if command == 'map':
            FIGHTSKIP = 1
            NORTHQ = int(playerY)+1
            SOUTHQ = int(playerY)-1
            EASTQ = int(playerX)+1
            WESTQ = int(playerX)-1
            CANNORTH = ('c:\\realms\\loc\\'+str(playerX)+' '+str(NORTHQ)+'.loc')
            CANSOUTH = ('c:\\realms\\loc\\'+str(playerX)+' '+str(SOUTHQ)+'.loc')
            CANEAST = ('c:\\realms\\loc\\'+str(EASTQ)+' '+str(playerY)+'.loc')
            CANWEST = ('c:\\realms\\loc\\'+str(WESTQ)+' '+str(playerY)+'.loc')
            try:
                open(CANNORTH)
                MAP1data = (CANNORTH)
                with open(MAP1data) as f:
                    mapcontent1 = f.readlines()
                    mapcontent1 = [x.strip('\n') for x in mapcontent1]
                AREADESC = mapcontent1[2]
                LOCKED = mapcontent1[3]
                print ('    To the north, '+str(AREADESC))
                if LOCKED == 'yes':
                    print('         However, the path is locked..')
            except:
                pass
            try:
                open(CANSOUTH)
                MAP2data = (CANSOUTH)
                with open(MAP2data) as f:
                    mapcontent2 = f.readlines()
                    mapcontent2 = [x.strip('\n') for x in mapcontent2]
                AREADESC = mapcontent2[2]
                LOCKED = mapcontent2[3]
                print ('    To the south, '+str(AREADESC))
                if LOCKED == 'yes':
                    print('         However, the path is locked..')
            except:
                pass
            try:
                open(CANEAST)
                MAP3data = (CANEAST)
                with open(MAP3data) as f:
                    mapcontent3 = f.readlines()
                    mapcontent3 = [x.strip('\n') for x in mapcontent3]
                AREADESC = mapcontent3[2]
                LOCKED = mapcontent3[3]
                print ('    To the east, '+str(AREADESC))
                if LOCKED == 'yes':
                    print('         However, the path is locked..')
            except:
                pass
            try:
                open(CANWEST)
                MAP4data = (CANWEST)
                with open(MAP4data) as f:
                    mapcontent4 = f.readlines()
                    mapcontent4 = [x.strip('\n') for x in mapcontent4]
                AREADESC = mapcontent4[2]
                LOCKED = mapcontent4[3]
                print ('    To the west, '+str(AREADESC))
                if LOCKED == 'yes':
                    print('         However, the path is locked..')
            except:
                pass

        if command == 'st':
            command = 'stats'
        if command == 'stat':
            command = 'stats'
        if command == 'stats':
            FIGHTSKIP = 1
            print (' ')
            print (' ')
            print ('     ')
            print ('                         LVL: ' + str(playerlvl) + '  EXP:' + str(playerexp) + '   NXT:' + str(NEXTLEVEL))
            print ('                          HP: '+str(playerhealth)+' / '+str(playermaxhealth))
            print ('                          MP: '+str(playermana)+' / '+str(playermaxmana)+'      $' + str(playercash))
            print ('                        ============================')
            print ('                             STRENGTH:   -=-   ' + str(playerstr))
            print ('                                 LUCK:   -=-   ' + str(playerluk))
            print ('                            DEXTERITY:   -=-   ' + str(playerdex))
            print ('                             CHARISMA:   -=-   ' + str(playercha))
            print ('                         INTELLIGENCE:   -=-   ' + str(playerint))
            print ('                        ============================')
            print ('                          Location: ' + LOCname)
            print ('                          Weapon: ' + str(playerwep))
            print ('                          Armor: '+ str(playerarm))
            REALDAMAGE = int(playerdam) * int(playerstr)
            DEXMOD = int(playerdex)+1
            DEXMOD = int(DEXMOD)/2
            REALDAMAGE = int(REALDAMAGE) + int(DEXMOD)
            LUCKMAX = 5 * int(playerluk)
            LUCKMAX = int(LUCKMAX) + int(REALDAMAGE)
            print ('                          Attack:  ' + str(REALDAMAGE)+' - '+str(LUCKMAX))
            print ('                          Defense: ' + str(playerdef))  
            if playercomp != 'none':
                compandata = ('C:\\Realms\\NPC\\'+str(playercomp)+'.npc')
                with open(compandata) as f:
                    compdat = f.readlines()
                    compdat = [x.strip('\n') for x in compdat]
                compatk = compdat[0]
                compdef = compdat[1]
                compinvcap = compdat[2]
                compidle = compdat[3]
                comphire = compdat[4]
                compfire = compdat[5]
                comphp  = compdat[6]
                compmaxhp = compdat[7]
                comphealskill = compdat[8]
                compheallim = compdat[9]
                compatkskill = compdat[10]
                compatkchance = compdat[11]
                compatk1 = compdat[12]
                compatk2 = compdat[13]
                compatk3 = compdat[14]
                compatk4 = compdat[15]
                compatk5 = compdat[16]
                print ('                          Companion: ' + str(playercomp))
            print (' ')
            print (' ')
            print (' ')
                
        if command == 'l':
            command = 'locale'
        if command == 'locale':
            FIGHTSKIP = 1
            LOCATIONCHECK()

        if command == 'cb':
            command = 'compbag'
        if command == 'compbag':
            if playercomp != 'none':
                compandata = ('C:\\Realms\\NPC\\'+str(playercomp)+'.npc')
                with open(compandata) as f:
                    compdat = f.readlines()
                    compdat = [x.strip('\n') for x in compdat]
                compinvcap = compdat[2]
                try:
                    compinventory.remove('')
                    compinventory.remove('')
                    compinventory.remove('')
                    compinventory.remove('')
                    compinventory.remove('')
                    compinventory.remove('')
                    compinventory.remove('')
                    compinventory.remove('')
                    compinventory.remove('')
                    compinventory.remove('')
                    compinventory.remove('')
                    compinventory.remove('')
                except:
                    pass
                ITEMNUMBER = 0
                for x in compinventory:
                    ITEMNUMBER = int(ITEMNUMBER)+1
                print ('        '+str(ITEMNUMBER) + ' / ' + str(compinvcap))
                FIGHTSKIP = 1
    
                if compinventory != []:
                    print (' ')
                    for y in compinventory:
                        INSdata = ('C:\Realms\ITM\\'+str(y)+ '.itm')
                        with open(INSdata) as f:
                            content = f.readlines()
                            content = [x.strip('\n') for x in content]
                        ITEMCLASS = content[0]
                        ITEMSTMOD = content[1]
                        ITEMSTNUM = content[2]
                        ITEMDESC = content[3]
                        ITEMDAM = content[4]
                        ITEMDEF = content[5]
                        ITEMKEY = content[6]
                        ITEMVAL = content[7]
                        print ('            ____________')
                        print ('        -=[ '+str(y))
                        print ('            $'+str(ITEMVAL))
                    print (' ')
    
                else:
                    print ('['+playername+'] Companion bag is empty.')
            else:
                print ('['+playername+'] I have no companion.')



        if command == 'b':
            command = 'bag'
        if command == 'bag':
            print ('        '+str(playerinvnumber) + ' / ' + str(playerinvlimit))
            FIGHTSKIP = 1
            try:
                playerinventory.remove('')
                playerinventory.remove('')
                playerinventory.remove('')
                playerinventory.remove('')
                playerinventory.remove('')
                playerinventory.remove('')
                playerinventory.remove('')
                playerinventory.remove('')
                playerinventory.remove('')
                playerinventory.remove('')
                playerinventory.remove('')
                playerinventory.remove('')
                playerinventory.remove('')
                playerinventory.remove('')
                playerinventory.remove('')
                playerinventory.remove('')
                playerinventory.remove('')
                playerinventory.remove('')
                playerinventory.remove('')
                playerinventory.remove('')
            except:
                pass
            if playerinventory != []:
                print (' ')
                for y in playerinventory:
                    INSdata = ('C:\Realms\ITM\\'+str(y)+ '.itm')
                    with open(INSdata) as f:
                        content = f.readlines()
                        content = [x.strip('\n') for x in content]
                    ITEMCLASS = content[0]
                    ITEMSTMOD = content[1]
                    ITEMSTNUM = content[2]
                    ITEMDESC = content[3]
                    ITEMDAM = content[4]
                    ITEMDEF = content[5]
                    ITEMKEY = content[6]
                    ITEMVAL = content[7]
                    print ('            ____________')
                    print ('        -=[ '+str(y))
                    print ('            $'+str(ITEMVAL))
                print (' ')

            else:
                print ('['+playername+'] My bag is empty.')

        if command == 'take':
            if playercomp != 'none':
                FIGHTSKIP = 1
                takeitem = raw_input('['+playername+'] Item: ')
                if takeitem in compinventory:
                    playerinventory.append(takeitem)
                    compinventory.remove(takeitem)
                    print ('['+playername+'] You take the '+str(takeitem)+' from '+str(playercomp)+'.')
                    playerinvnumber = int(playerinvnumber)+1
                else:
                    print ('['+playername+'] My companion isn\'t holding that.')
            else:
                print ('['+playername+'] I don\'t have a companion.')
                
                
        if command == 'give':
            FIGHTSKIP = 1
            if playercomp != 'none':
                compandata = ('C:\\Realms\\NPC\\'+str(playercomp)+'.npc')
                with open(compandata) as f:
                    compdat = f.readlines()
                    compdat = [x.strip('\n') for x in compdat]
                compinvcap = compdat[2]
                try:
                    compinventory.remove('')
                    compinventory.remove('')
                    compinventory.remove('')
                    compinventory.remove('')
                    compinventory.remove('')
                    compinventory.remove('')
                    compinventory.remove('')
                    compinventory.remove('')
                    compinventory.remove('')
                    compinventory.remove('')
                    compinventory.remove('')
                    compinventory.remove('')
                except:
                    pass
                ITEMNUMBER = 0
                for x in compinventory:
                    ITEMNUMBER = int(ITEMNUMBER)+1
                print ('        '+str(ITEMNUMBER) + ' / ' + str(compinvcap))
                FIGHTSKIP = 1
                if int(ITEMNUMBER) < int(compinvcap):
                    giveitem = raw_input('['+playername+'] Give: ')
                    if giveitem in playerinventory:
                        playerinventory.remove(giveitem)
                        compinventory.append(giveitem)
                        print ('['+playername+'] You hand the '+str(giveitem)+' to '+str(playercomp)+'.')
                        playerinvnumber = int(playerinvnumber)-1
                        
                    else:
                        print ('['+playername+'] You aren\'t holding one of those.')
                else:
                    print ('['+playername+'] '+playercomp+' can\'t hold any more.')
            else:
                print ('['+playername+'] I have no companion.')


        if command == 'g':
            command = 'grab'
        if command == 'grab':
            FIGHTSKIP = 1
            if int(playerinvnumber) < int(playerinvlimit):
                GRABITEM = raw_input('['+playername+'] Grab: ')
                if GRABITEM == '':
                    GRABITEM = 'NONE'
                if GRABITEM == 'all':
                    try:
                        localinventory.remove('')
                        localinventory.remove('')
                        localinventory.remove('')
                        localinventory.remove('')
                        localinventory.remove('')
                        localinventory.remove('')
                        localinventory.remove('')
                        localinventory.remove('')
                        localinventory.remove('')
                        localinventory.remove('')
                        localinventory.remove('')
                    except:
                        pass
                    while int(playerinvnumber) < int(playerinvlimit) and localinventory != []:
                        for x in localinventory:
                            if int(playerinvnumber) < int(playerinvlimit):
                                try:
                                    playerinvnumber = int(playerinvnumber)+1
                                    playerinventory.insert(0,x)
                                    localinventory.remove(x)
                                    print ('['+playername+'] You pick up and store the '+str(x))
                                except:
                                    print ('EXCEPTION ON ALL GRAB TRY')
                            else:
                                print ('['+playername+'] I can\'t carry any more.')
                                
                elif GRABITEM in localinventory:
                    playerinvnumber = int(playerinvnumber)+1
                    playerinventory.insert(0,GRABITEM)
                    localinventory.remove(GRABITEM)
                    print ('['+playername+'] You pick up and store the '+GRABITEM)
                else:
                    print ('['+playername+'] No such item. ')
            else:
                print ('['+playername+'] I can\'t carry any more. ')
        if command == 'eq':
            command = 'equip'
        if command == 'equip':
            FIGHTSKIP = 1
            EQUIPITEM = raw_input('['+playername+'] Equip: ')

            if EQUIPITEM in playerinventory:
                EQUIPdata = ('C:\Realms\ITM\\'+str(EQUIPITEM)+ '.itm')
                with open(EQUIPdata) as f:
                    content = f.readlines()
                    content = [x.strip('\n') for x in content]
                ITEMCLASS = content[0]
                ITEMSTMOD = content[1]
                ITEMSTNUM = content[2]
                ITEMDESC = content[3]
                ITEMDAM = content[4]
                ITEMDEF = content[5]
                ITEMKEY = content[6]
                ITEMVAL = content[7]
                if ITEMCLASS == 'weapon' and playerwep == 'empty':
                    if ITEMSTMOD != 'none':
                        if ITEMSTMOD == 'playerstr':
                            playerstr = int(playerstr)+int(ITEMSTNUM)
                        if ITEMSTMOD == 'playerluk':
                            playerluk = int(playerluk)+int(ITEMSTNUM)
                        if ITEMSTMOD == 'playercha':
                            playercha = int(playercha)+int(ITEMSTNUM)
                        if ITEMSTMOD == 'playerdex':
                            playerdex = int(playerdex)+int(ITEMSTNUM)
                        if ITEMSTMOD == 'playerint':
                            playerluk = int(playerint)+int(ITEMSTNUM)
                        if ITEMSTMOD == 'playermaxhealth':
                            playermaxhealth = int(playermaxhealth)+int(ITEMSTNUM)
                            
                    playerwep = EQUIPITEM
                    playerinventory.remove(EQUIPITEM)
                    playerinvnumber = int(playerinvnumber)-1
                    playerdam = int(playerdam)+int(ITEMDAM)
                    print ('['+playername+'] Hopefully this '+str(EQUIPITEM)+' can do some damage.')
                elif ITEMCLASS == 'armor' and playerarm == 'empty':
                    PLACEHOLDER = 1
                    if ITEMSTMOD != 'none':
                        if ITEMSTMOD == 'playerstr':
                            playerstr = int(playerstr)+int(ITEMSTNUM)
                        if ITEMSTMOD == 'playerluk':
                            playerluk = int(playerluk)+int(ITEMSTNUM)
                        if ITEMSTMOD == 'playercha':
                            playercha = int(playercha)+int(ITEMSTNUM)
                        if ITEMSTMOD == 'playerdex':
                            playerdex = int(playerdex)+int(ITEMSTNUM)
                        if ITEMSTMOD == 'playerint':
                            playerint = int(playerint)+int(ITEMSTNUM)
                        if ITEMSTMOD == 'playermaxhealth':
                            playermaxhealth = int(playermaxhealth)+int(ITEMSTNUM)
                    playerarm = EQUIPITEM
                    playerinventory.remove(EQUIPITEM)
                    playerinvnumber = int(playerinvnumber)-1
                    playerdef = int(playerdef)+int(ITEMDEF)
                    print ('['+playername+'] Hopefully this '+str(EQUIPITEM)+' keeps me safe.')
                else:
                    print ('['+playername+'] I cannot equip that. ')
                    if ITEMCLASS == 'weapon' and playerwep != 'empty':
                        print ('['+playername+'] I should unequip my current weapon first.')
                    if ITEMCLASS == 'armor' and playerarm != 'empty':
                        print ('['+playername+'] I should unequip my current armor first.')
            else:
                print ('['+playername+'] I have no such item to equip. ')



        if command == 'uneq':
            command = 'unequip'
        if command == 'unequip':
            FIGHTSKIP = 1
            EQUIPITEM = raw_input('['+playername+'] Unequip: ')
            if EQUIPITEM == playerwep or EQUIPITEM == playerarm:
                if int(playerinvnumber) < int(playerinvlimit):
    #####BEGIN INV CHECK TAB########
                    EQUIPdata = ('C:\Realms\ITM\\'+str(EQUIPITEM)+ '.itm')
                    with open(EQUIPdata) as f:
                        content = f.readlines()
                        content = [x.strip('\n') for x in content]
                    ITEMCLASS = content[0]
                    ITEMSTMOD = content[1]
                    ITEMSTNUM = content[2]
                    ITEMDESC = content[3]
                    ITEMDAM = content[4]
                    ITEMDEF = content[5]
                    ITEMKEY = content[6]
                    ITEMVAL = content[7]
                
                    if ITEMCLASS == 'weapon':
                        if ITEMSTMOD != 'none':
                            if ITEMSTMOD == 'playerstr':
                                playerstr = int(playerstr)-int(ITEMSTNUM)
                            if ITEMSTMOD == 'playercha':
                                playercha = int(playercha)-int(ITEMSTNUM)
                            if ITEMSTMOD == 'playerdex':
                                playerdex = int(playerdex)-int(ITEMSTNUM)
                            if ITEMSTMOD == 'playerluk':
                                playerluk = int(playerluk)-int(ITEMSTNUM)
                            if ITEMSTMOD == 'playerint':
                                playerluk = int(playerint)-int(ITEMSTNUM)
                            if ITEMSTMOD == 'playermaxhealth':
                                playermaxhealth = int(playermaxhealth)-int(ITEMSTNUM)
                        playerwep = 'empty'
                        playerinventory.insert(0,EQUIPITEM)
                        playerdam = int(playerdam)-int(ITEMDAM)
                        playerinvnumber = int(playerinvnumber)+1
                        print ('['+playername+'] No need for this anymore.')
                    elif ITEMCLASS == 'armor':
                        if ITEMSTMOD != 'none':
                            if ITEMSTMOD == 'playerstr':
                                playerstr = int(playerstr)-int(ITEMSTNUM)
                            if ITEMSTMOD == 'playerluk':
                                playerluk = int(playerluk)-int(ITEMSTNUM)
                            if ITEMSTMOD == 'playercha':
                                playercha = int(playercha)-int(ITEMSTNUM)
                            if ITEMSTMOD == 'playerdex':
                                playerdex = int(playerdex)-int(ITEMSTNUM)
                            if ITEMSTMOD == 'playerint':
                                playerluk = int(playerint)-int(ITEMSTNUM)
                            if ITEMSTMOD == 'playermaxhealth':
                                playermaxhealth = int(playermaxhealth)-int(ITEMSTNUM)
                        playerarm = 'empty'
                        playerinventory.insert(0,EQUIPITEM)
                        playerdef = int(playerdef)-int(ITEMDEF)
                        playerinvnumber = int(playerinvnumber)+1
                        print ('['+playername+'] I should be fine without this.')
                    else:
                        print ('['+playername+'] How the hell did I equip that anyway? ')
                else:
                    print ('['+playername+'] No room in my bag for that. ')
            else:
                print ('['+playername+'] I do not have that equipped. ')
        if command == 'd':
            command = 'drop'
        if command == 'drop':
            FIGHTSKIP = 1
            DROPITEM = raw_input('['+playername+'] Drop: ')
            if DROPITEM == '':
                DROPITEM = 'NONE'
            if DROPITEM in playerinventory:
                localinventory.insert(0,DROPITEM)
                playerinventory.remove(DROPITEM)
                playerinvnumber = int(playerinvnumber)-1
                print ('['+playername+'] You drop the '+DROPITEM+' at your feet.')
            else:
                print ('['+playername+'] No such item. ')
        if command == 't':
            command = 'toss'
        if command == 'toss':
            FIGHTSKIP = 1
            DROPITEM = raw_input('['+playername+'] Toss: ')
            if DROPITEM == '':
                DROPITEM = 'NONE'
            if DROPITEM in playerinventory:
                playerinventory.remove(DROPITEM)
                playerinvnumber = int(playerinvnumber)-1
                print ('['+playername+'] You throw away the '+DROPITEM+'.')
            else:
                print ('['+playername+'] No such item. ')

        if command == 'se':
            command = 'search'
        if command == 'search':
            try:
                localinventory.remove('')
                localinventory.remove('')
                localinventory.remove('')
                localinventory.remove('')
                localinventory.remove('')
                localinventory.remove('')
                localinventory.remove('')
                localinventory.remove('')
                localinventory.remove('')
                localinventory.remove('')
                localinventory.remove('')
                localinventory.remove('')
                localinventory.remove('')
                localinventory.remove('')
                localinventory.remove('')
                localinventory.remove('')
                localinventory.remove('')
                localinventory.remove('')
            except:
                pass
 
            print ('['+playername+'] Let\'s see what we can find..')
            if not localinventory:
                print ('['+playername+'] I\'m not finding anything useful.')
            else:
                print ('['+playername+'] Hmm, would you look at that.')
                for x in localinventory:
                    print ('                 _________')
                    print ('                | '+str(x))

        if command == 'u':
            command = 'use'
        if command == 'use':
            INSPITEM = raw_input('['+playername+'] Item: ')
            if INSPITEM == '':
                INSPITEM = 'NONE'
            if INSPITEM in playerinventory:
                INSdata = ('C:\Realms\ITM\\'+INSPITEM+ '.itm')
                with open(INSdata) as f:
                    content = f.readlines()
                    content = [x.strip('\n') for x in content]
                ITEMCLASS = content[0]
                ITEMSTMOD = content[1]
                ITEMSTNUM = content[2]
                ITEMDESC = content[3]
                ITEMDAM = content[4]
                ITEMDEF = content[5]
                ITEMKEY = content[6]
                ITEMVAL = content[7]
                
                if ITEMCLASS == 'key':
                    NORTHQ = int(playerY)+1
                    SOUTHQ = int(playerY)-1
                    EASTQ = int(playerX)+1
                    WESTQ = int(playerX)-1
                    KEYNORTH = (str(playerX)+' '+str(NORTHQ))
                    KEYSOUTH = (str(playerX)+' '+str(SOUTHQ))
                    KEYEAST = (str(EASTQ)+' '+str(playerY))
                    KEYWEST = (str(WESTQ)+' '+str(playerY))
                    if ITEMKEY == KEYNORTH or ITEMKEY == KEYSOUTH or ITEMKEY == KEYEAST or ITEMKEY == KEYWEST:
                        if ITEMKEY == KEYNORTH:
                            with open('c:\\realms\\LOC\\'+str(KEYNORTH)+'.loc') as f:
                                localdata = f.read().split('\n')
                                localdata.remove('yes')
                                localdata.insert(3,'no')
                                open('C:\\Realms\\LOC\\'+str(KEYNORTH)+'.loc', "w").close()
                                with open('C:\\Realms\\LOC\\'+str(KEYNORTH)+'.loc', "w") as f:
                                    for s in localdata:
                                        f.write(s + '\n')
                            playerinventory.remove(INSPITEM)
                            playerinvnumber = int(playerinvnumber)-1
                        if ITEMKEY == KEYSOUTH:
                            with open('c:\\realms\\LOC\\'+str(KEYSOUTH)+'.loc') as f:
                                localdata = f.read().split('\n')
                                localdata.remove('yes')
                                localdata.insert(3,'no')
                                open('C:\\Realms\\LOC\\'+str(KEYSOUTH)+'.loc', "w").close()
                                with open('C:\\Realms\\LOC\\'+str(KEYSOUTH)+'.loc', "w") as f:
                                    for s in localdata:
                                        f.write(s + '\n')
                            playerinventory.remove(INSPITEM)
                            playerinvnumber = int(playerinvnumber)-1
                        if ITEMKEY == KEYEAST:
                            with open('c:\\realms\\LOC\\'+str(KEYEAST)+'.loc') as f:
                                localdata = f.read().split('\n')
                                localdata.remove('yes')
                                localdata.insert(3,'no')
                                open('C:\\Realms\\LOC\\'+str(KEYEAST)+'.loc', "w").close()
                                with open('C:\\Realms\\LOC\\'+str(KEYEAST)+'.loc', "w") as f:
                                    for s in localdata:
                                        f.write(s + '\n')
                            playerinventory.remove(INSPITEM)
                            playerinvnumber = int(playerinvnumber)-1
                        if ITEMKEY == KEYWEST:
                            with open('c:\\realms\\LOC\\'+str(KEYWEST)+'.loc') as f:
                                localdata = f.read().split('\n')
                                localdata.remove('yes')
                                localdata.insert(3,'no')
                                open('C:\\Realms\\LOC\\'+str(KEYWEST)+'.loc', "w").close()
                                with open('C:\\Realms\\LOC\\'+str(KEYWEST)+'.loc', "w") as f:
                                    for s in localdata:
                                        f.write(s + '\n')
                            playerinventory.remove(INSPITEM)
                            playerinvnumber = int(playerinvnumber)-1
                        print('['+str(playername)+'] Looks like that did the trick.')
                    else:
                        print('['+str(playername)+'] This doesn\'t fit into anything around here.')
                        
                if ITEMCLASS == 'potion':
                    if ITEMSTMOD != 'none':
                        if ITEMSTMOD == 'teleport':
                            print('['+str(playername)+'] You are whisked away in an instant.')
                            NEWCO = ITEMSTNUM.split(' ')
                            global playerX
                            playerX = NEWCO[0]
                            global playerY
                            playerY = NEWCO[1]
                            LOCATIONCHECK()
                            playerinventory.remove(INSPITEM)
                            playerinvnumber = int(playerinvnumber)-1

                        if ITEMSTMOD == 'playerstr':
                            print('['+str(playername)+'] You feel like your muscles are growing..')
                            playerstr = int(playerstr)+int(ITEMSTNUM)
                            playerinventory.remove(INSPITEM)
                            playerinvnumber = int(playerinvnumber)-1
                        if ITEMSTMOD == 'playerluk':
                            print('['+str(playername)+'] You feel like lady luck is smiling at you today.')
                            playerluk = int(playerluk)+int(ITEMSTNUM)
                            playerinventory.remove(INSPITEM)
                            playerinvnumber = int(playerinvnumber)-1
                        if ITEMSTMOD == 'playerdex':
                            print('['+str(playername)+'] You feel swifter and more nimble.')
                            playerdex = int(playerdex)+int(ITEMSTNUM)
                            playerinventory.remove(INSPITEM)
                            playerinvnumber = int(playerinvnumber)-1
                        if ITEMSTMOD == 'playercha':
                            print('['+str(playername)+'] You feel more suave than ever.')
                            playercha = int(playercha)+int(ITEMSTNUM)
                            playerinventory.remove(INSPITEM)
                            playerinvnumber = int(playerinvnumber)-1
                        if ITEMSTMOD == 'playerint':
                            print('['+str(playername)+'] You feel your conciousness expand..')
                            playerint = int(playerint)+int(ITEMSTNUM)
                            playerinventory.remove(INSPITEM)
                            playerinvnumber = int(playerinvnumber)-1
                        if ITEMSTMOD == 'playercash':
                            print('['+str(playername)+'] Your wallet feels hefty.')
                            playercash = int(playercash)+int(ITEMSTNUM)
                            playerinventory.remove(INSPITEM)
                            playerinvnumber = int(playerinvnumber)-1
                        if ITEMSTMOD == 'playerlvl':
                            print('['+str(playername)+'] You feel more experienced.')
                            playerexp = int(playerexp)+int(ITEMSTNUM)
                            playerinventory.remove(INSPITEM)
                            playerinvnumber = int(playerinvnumber)-1
                        if ITEMSTMOD == 'playermaxhealth':
                            print('['+str(playername)+'] You feel healthier than ever before.')
                            playermaxhealth = int(playermaxhealth)+int(ITEMSTNUM)
                            playerinventory.remove(INSPITEM)
                            playerinvnumber = int(playerinvnumber)-1
                        if ITEMSTMOD == 'skillbook':
                            playerinventory.remove(INSPITEM)
                            playerskills.insert(0,ITEMSTNUM)
                            playerinvnumber = int(playerinvnumber)-1
                            print ('['+playername+'] You have gained knowledge of '+str(ITEMSTNUM))
                        if ITEMSTMOD == 'playermaxmana':
                            print('['+str(playername)+'] You feel more energetic than ever.')
                            playermaxmana = int(playermaxmana)+int(ITEMSTNUM)
                            playerinventory.remove(INSPITEM)
                            playerinvnumber = int(playerinvnumber)-1
                            
                        if ITEMSTMOD == 'bagexpand':
                            print('['+str(playername)+'] You equip your new bag.')
                            playerinvlimit = int(ITEMSTNUM)
                            playerinventory.remove(INSPITEM)
                            playerinvnumber = int(playerinvnumber)-1
                        if ITEMSTMOD == 'playerhealth':
                            print('['+str(playername)+'] You feel revitalized and renewed!')
                            playerhealth = int(playerhealth)+int(ITEMSTNUM)
                            playerinventory.remove(INSPITEM)
                            playerinvnumber = int(playerinvnumber)-1
                            if int(playerhealth) > int(playermaxhealth):
                                playerhealth = playermaxhealth
                        if ITEMSTMOD == 'playermana':
                            print('['+str(playername)+'] You feel refreshed and energetic!')
                            playermana = int(playermana)+int(ITEMSTNUM)
                            playerinventory.remove(INSPITEM)
                            playerinvnumber = int(playerinvnumber)-1
                            if int(playermana) > int(playermaxmana):
                                playermana = playermaxmana
                        else:
                            pass
                    else:
                        print ('['+str(playername)+'] I cannot use that right now.')
            else:
                print ('['+str(playername)+'] I have no such item.')
                
        if command == 'i':
            command = 'inspect'
        if command == 'inspect':
            FIGHTSKIP = 1
            INSPECTFUNCTION()
            ###

            
#########   CREATION CONSONE    ###########
            
        if command == godcommand:
            FIGHTSKIP = 1
        #########
            SCREENCLEAR()
            print ('Godmode On')
            print ('CURRENT AREA')
            print ('X='+str(playerX)+'  Y='+str(playerY))  
            def MELON():
                global frootNet
                frootNet = False
         
            def MELOFF():
                global frootNet
                frootNet = True    
            MELON()
            while frootNet == False:
                EDITCMD = raw_input('[GOD]: ' )

                if EDITCMD == 'exportchar':
                    global playerhealth
                    FIGHTSKIP = 1
                    EXPORT = raw_input('[GOD]WORLD: ')
                    try:
                        open('C:\\Realms\\Worlds\\'+EXPORT+'\\SAV\\'+playername+'.sav', "w").close()
                    except:
                        pass
                    writfile = open('C:\\Realms\\Worlds\\'+EXPORT+'\\SAV\\'+playername+'.sav', "w")      
                    writfile.write(str(playername) +'\n')
                    writfile.write(str(playerstr) +'\n')
                    writfile.write(str(playerluk) +'\n')
                    writfile.write(str(playerdex) +'\n')
                    writfile.write(str(playercha) +'\n')
                    writfile.write(str(playerint) +'\n')
                    writfile.write(str(playerlvl) +'\n')
                    writfile.write(str(playerexp) +'\n')
                    writfile.write(str(playercash) +'\n')
                    writfile.write(str(playerX) +'\n')
                    writfile.write(str(playerY) +'\n')
                    writfile.write(str(playerhealth) +'\n')
                    writfile.write(str(playermaxhealth) +'\n')
                    writfile.write(str(playerdam) +'\n')
                    writfile.write(str(playerdef) +'\n')
                    writfile.write(str(playerinvlimit) +'\n')
                    writfile.write(str(playerinvnumber) +'\n')
                    writfile.write(str(godcommand) +'\n')
                    writfile.write(str(playermana) +'\n')
                    writfile.write(str(playermaxmana) +'\n')
                    writfile.write(str(playerwep) +'\n')
                    writfile.write(str(playerarm) +'\n')
                    writfile.write(str(playercomp) +'\n')
                    writfile.close()

#####INVENTORY SAVER######
                    try:
                        open('C:\\Realms\\Worlds\\'+EXPORT+'\\INV\\'+playername+'.inv', "w").close()
                    except:
                        pass
                    with open('C:\\Realms\\Worlds\\'+EXPORT+'\\INV\\'+playername+'.inv', "w") as f:
                        for s in playerinventory:
                            f.write(s + '\n')
                    try:
                        open('C:\\Realms\\Worlds\\'+EXPORT+'\\INV\\'+str(playerX)+' '+str(playerY)+'.inv', "w").close()
                    except:
                        pass
                    with open('C:\\Realms\\Worlds\\'+EXPORT+'\\INV\\'+str(playerX)+' '+str(playerY)+'.inv', "w") as f:
                        for L in localinventory:
                            f.write(L + '\n')

                    try:
                        open('C:\\Realms\\Worlds\\'+EXPORT+'\\INV\\'+playername+'.skl', "w").close()
                    except:
                        pass
                    with open('C:\\Realms\\Worlds\\'+EXPORT+'\\INV\\'+playername+'.skl', "w") as f:
                        for s in playerskills:
                            f.write(s + '\n') 
###########################

                    print ('['+playername+'] Progress has been exported to '+str(EXPORT)+'!')


                if EDITCMD == 'setcompanion':
                    print ('[OPTIONS] Enter name of companion, or \'none\'.')
                    NEWCOMP = raw_input('[GOD]NAME: ')
                    if NEWCOMP == 'none':
                        playercomp = 'none'
                        print ('[GOD] Companion set to none')
                    else:
                        try:
                            open('C:\\Realms\\NPC\\'+ NEWCOMP +'.npc')
                            playercomp = NEWCOMP
                            print ('[GOD] Companion set to '+str(NEWCOMP))
                        except:
                            print ('[GOD] No such companion.')

                if EDITCMD == 'edit':
                    ITEM = raw_input('[GOD]Name: ')
                    try:
                        open('C:\\Realms\\INV\\'+str(ITEM)+'.cmp')
                        os.system('start notepad C:\\Realms\\INV\\'+str(ITEM)+'.cmp')
                    except:
                        pass

                    try:
                        open('C:\\Realms\\NPC\\'+str(ITEM)+'.npc')
                        os.system('start notepad C:\\Realms\\NPC\\'+str(ITEM)+'.npc')
                    except:
                        pass
                    try:
                        open('C:\\Realms\\NPC\\'+str(ITEM)+'.inv')
                        os.system('start notepad C:\\Realms\\NPC\\'+str(ITEM)+'.inv')
                    except:
                        pass
                    try:
                        open('C:\\Realms\\NPC\\'+str(ITEM)+'.gos')
                        os.system('start notepad C:\\Realms\\NPC\\'+str(ITEM)+'.gos')
                    except:
                        pass
                    try:
                        open('C:\\Realms\\INV\\'+str(ITEM)+'.chk')
                        os.system('start notepad C:\\Realms\\INV\\'+str(ITEM)+'.chk')
                    except:
                        pass
                    try:
                        open('C:\\Realms\\ENM\\'+str(ITEM)+'.enm')
                        os.system('start notepad C:\\Realms\\ENM\\'+str(ITEM)+'.enm')
                    except:
                        pass
                    try:
                        open('C:\\Realms\\EVT\\'+str(ITEM)+'.eve')
                        os.system('start notepad C:\\Realms\\EVT\\'+str(ITEM)+'.eve')
                    except:
                        pass
                    try:
                        open('C:\\Realms\\ITM\\'+str(ITEM)+'.itm')
                        os.system('start notepad C:\\Realms\\ITM\\'+str(ITEM)+'.itm')
                    except:
                        pass
                    try:
                        open('C:\\Realms\\ITM\\'+str(ITEM)+'.atk')
                        os.system('start notepad C:\\Realms\\ITM\\'+str(ITEM)+'.atk')
                    except:
                        pass
                    try:
                        open('C:\\Realms\\INV\\'+str(ITEM)+'.inv')
                        os.system('start notepad C:\\Realms\\INV\\'+str(ITEM)+'.inv')
                    except:
                        pass
                    try:
                        open('C:\\Realms\\LOC\\'+str(ITEM)+'.loc')
                        os.system('start notepad C:\\Realms\\LOC\\'+str(ITEM)+'.loc')
                    except:
                        pass
                    try:
                        open('C:\\Realms\\SAV\\'+str(ITEM)+'.sav')
                        os.system('start notepad C:\\Realms\\SAV\\'+str(ITEM)+'.sav')
                    except:
                        pass
                    try:
                        open('C:\\Realms\\ITM\\'+str(ITEM)+'.skl')
                        os.system('start notepad C:\\Realms\\ITM\\'+str(ITEM)+'.skl')
                    except:
                        pass
                    try:
                        open('C:\\Realms\\INV\\'+str(ITEM)+'.gos')
                        os.system('start notepad C:\\Realms\\INV\\'+str(ITEM)+'.gos')
                    except:
                        pass
                    try:
                        open('C:\\Realms\\INV\\'+str(ITEM)+'.mch')
                        os.system('start notepad C:\\Realms\\INV\\'+str(ITEM)+'.mch')
                    except:
                        pass
                    try:
                        open('C:\\Realms\\INV\\'+str(ITEM)+'.eve')
                        os.system('start notepad C:\\Realms\\INV\\'+str(ITEM)+'.eve')
                    except:
                        pass
                    try:
                        open('C:\\Realms\\INV\\'+str(ITEM)+'.enm')
                        os.system('start notepad C:\\Realms\\INV\\'+str(ITEM)+'.enm')
                    except:
                        pass
                if EDITCMD == 'allmerchants':
                    #####   os.system('dir c:\\realms\\INV\\*.mch')
                    print (' ')
                    asps = []
                    for root, dirs, files in os.walk('C:\\Realms\\INV'):
                        for file in files:
                            if file.endswith('.mch'):
                                file = file.strip('.mch')
                                asps.append(str(file)+str('.loc'))
                    for y in asps:
                        LOCdata = ('C:\Realms\LOC\\'+str(y))
                        with open(LOCdata) as f:
                            content = f.readlines()
                            content = [x.strip('\n') for x in content]
                            AREANAME = content[0]
                            print (' '+str(y)+' - '+AREANAME)
                    print (' ')
                    
                if EDITCMD == 'allstatchecks':
                    #####   os.system('dir c:\\realms\\INV\\*.mch')
                    print (' ')
                    asps = []
                    for root, dirs, files in os.walk('C:\\Realms\\INV'):
                        for file in files:
                            if file.endswith('.chk'):
                                file = file.strip('.chk')
                                asps.append(str(file)+str('.loc'))
                    for y in asps:
                        LOCdata = ('C:\Realms\LOC\\'+str(y))
                        with open(LOCdata) as f:
                            content = f.readlines()
                            content = [x.strip('\n') for x in content]
                            AREANAME = content[0]
                            print (' '+str(y)+' - '+AREANAME)
                    print (' ')
                    
                if EDITCMD == 'viewsource':
                    os.system('start C:\\realms\\realms.py')      
                if EDITCMD == 'allgossip':
                    #####   os.system('dir c:\\realms\\INV\\*.mch')
                    print (' ')
                    asps = []
                    for root, dirs, files in os.walk('C:\\Realms\\INV'):
                        for file in files:
                            if file.endswith('.gos'):
                                file = file.strip('.gos')
                                asps.append(str(file)+str('.loc'))
                    for y in asps:
                        LOCdata = ('C:\Realms\LOC\\'+str(y))
                        with open(LOCdata) as f:
                            content = f.readlines()
                            content = [x.strip('\n') for x in content]
                            AREANAME = content[0]
                            print (' '+str(y)+' - '+AREANAME)
                    print (' ')
                    
                    
                if EDITCMD == 'teleport':
                    global playerX
                    playerX = raw_input('[TELEPORT X:]')
                    global playerY
                    playerY = raw_input('[TELEPORT Y:]')
                    EDITCMD = godcommand
                    LOCATIONCHECK()

                if EDITCMD == 'setgod':
                    godcommand = raw_input('[GOD]COMMAND: ')
                if EDITCMD == 'destroyitem':
                    ITEM = raw_input('[GOD]ITEM: ')
                    os.system('del /s /q C:\\Realms\\ITM\\'+ITEM+'.itm')
                    os.system('del /s /q C:\\Realms\\ITM\\'+ITEM+'.skl')
                    os.system('del /s /q C:\\Realms\\ITM\\'+ITEM+'.atk')
                if EDITCMD == 'destroygossip':
                    COORDS = raw_input('[GOD]COORDS: ')
                    os.system('del /s /q C:\\Realms\\INV\\'+COORDS+'.gos')
                if EDITCMD == 'destroyarea':
                    ITEM = raw_input('[GOD]AREA COORDS: ')
                    os.system('del /s /q C:\\Realms\\LOC\\'+ITEM+'.loc')
                if EDITCMD == 'destroyskill':
                    ITEM = raw_input('[GOD]SKILL: ')
                    os.system('del /s /q C:\\Realms\\ITM\\'+ITEM+'.skl')
                if EDITCMD == 'destroyevent':
                    EVENT = raw_input('[GOD]EVENT: ')
                    os.system('del /s /q C:\\Realms\\EVT\\'+EVENT+'.eve')
                if EDITCMD == 'destroyenemy':
                    EVENT = raw_input('[GOD]ENEMY: ')
                    os.system('del /s /q C:\\Realms\\ENM\\'+EVENT+'.enm')
                if EDITCMD == 'learnskill':
                    playerskills.insert( 0 , raw_input('[GOD]NAME: '))
                if EDITCMD == 'destroycharacter':
                    CHAR = raw_input('[GOD]CHAR: ')
                    os.system('del /s /q C:\\Realms\\INV\\'+CHAR+'.inv')
                    os.system('del /s /q C:\\Realms\\INV\\'+CHAR+'.skl')
                    os.system('del /s /q C:\\Realms\\SAV\\'+CHAR+'.sav')
                if EDITCMD == 'viewroot':
                    os.system('start C:\\Realms')
                        
                if EDITCMD == 'i':
                    EDITCMD = 'inspect'
                                                        
                if EDITCMD == 'destroymerchant':
                    NEWCOORDS = raw_input('[GOD]AREA: ')
                    os.system('del /s /q C:\\Realms\\INV\\'+NEWCOORDS+'.mch')
                if EDITCMD == 'destroystatcheck':
                    NEWCOORDS = raw_input('[GOD]AREA: ')
                    os.system('del /s /q C:\\Realms\\INV\\'+NEWCOORDS+'.chk')

                if EDITCMD == 'inspect':
                    global godmode
                    GODMODE = 'on'
                    INSPECTFUNCTION()
                    GODMODE = 'off'
                    
                if EDITCMD == 'setbagsize':
                    playerinvlimit = raw_input('[GOD]ITEM#LIMIT: ')
                    
                if EDITCMD == 'newmerchant':
                    NORTHQ = int(playerY)+1
                    SOUTHQ = int(playerY)-1
                    EASTQ = int(playerX)+1
                    WESTQ = int(playerX)-1
                    CANNORTH = ('c:\\realms\\loc\\'+str(playerX)+' '+str(NORTHQ)+'.loc')
                    CANSOUTH = ('c:\\realms\\loc\\'+str(playerX)+' '+str(SOUTHQ)+'.loc')
                    CANEAST = ('c:\\realms\\loc\\'+str(EASTQ)+' '+str(playerY)+'.loc')
                    CANWEST = ('c:\\realms\\loc\\'+str(WESTQ)+' '+str(playerY)+'.loc')
                    print ('[GOD]Input either coords or a direction for the area.')
                    NEWCOORDS = raw_input('[GOD]COORDINATES: ')
                    if NEWCOORDS == 'north':
                        NEWCOORDS = (str(playerX)+' '+str(NORTHQ))
                    if NEWCOORDS == 'south':
                        NEWCOORDS = (str(playerX)+' '+str(SOUTHQ))
                    if NEWCOORDS == 'east':
                        NEWCOORDS = (str(EASTQ)+' '+str(playerY))
                    if NEWCOORDS == 'west':
                        NEWCOORDS = (str(WESTQ)+' '+str(playerY))
                    writfile = open('C:\\Realms\\INV\\'+NEWCOORDS+'.mch', "w")
                    print ('[GOD]DESCRIPTION: ')
                    writfile.write(raw_input('')+'\n')
                    print '[OPTIONS] Input an itemname, or use 0 for nothing.'
                    writfile.write(raw_input('[GOD]ITEM1: ')+'\n')
                    writfile.write(raw_input('[GOD]ITEM2: ')+'\n')
                    writfile.write(raw_input('[GOD]ITEM3: ')+'\n')
                    writfile.write(raw_input('[GOD]ITEM4: ')+'\n')
                    writfile.write(raw_input('[GOD]ITEM5: ')+'\n')
                    writfile.write(raw_input('[GOD]ITEM6: ')+'\n')
                    writfile.write(raw_input('[GOD]ITEM7: ')+'\n')
                    writfile.write(raw_input('[GOD]ITEM8: ')+'\n')
                    writfile.write(raw_input('[GOD]ITEM9: ')+'\n')
                    writfile.write(raw_input('[GOD]ITEM10: ')+'\n')
                    writfile.close()
                    
                if EDITCMD == 'levelup':
                    playerexp = NEXTLEVEL

                if EDITCMD == 'newskill':
                    writfile = open('C:\\Realms\\ITM\\' + raw_input('[GOD}NAME:') + '.skl', "w")
                    print('[GOD]USE DESCRIPTION: ')
                    writfile.write(raw_input('')+'\n')
                    EFFECTNUM = raw_input('[OPTIONS] NUMBER OF EFFECTS, 1 to 3: ')
                    writfile.write(EFFECTNUM+'\n')
                    print ('[OPTIONS]: pierce, debuffatk, debuffdef, stun, selfharm')
                    print ('[OPTIONS]: healhp, playermp, atkboost, defboost, none')
                    writfile.write(raw_input('[GOD]EFFECT1: ')+'\n')
                    writfile.write(raw_input('[GOD]AMOUNT1: ')+'\n')
                    print ('[GOD]DESCRIPTION:')
                    writfile.write(raw_input('')+'\n')
                    writfile.write(raw_input('[GOD]EFFECT2: ')+'\n')
                    writfile.write(raw_input('[GOD]AMOUNT2: ')+'\n')
                    print ('[GOD]DESCRIPTION:')
                    writfile.write(raw_input('')+'\n')
                    writfile.write(raw_input('[GOD]EFFECT3: ')+'\n')
                    writfile.write(raw_input('[GOD]AMOUNT3: ')+'\n')
                    print ('[GOD]DESCRIPTION:')
                    writfile.write(raw_input('')+'\n')
                    writfile.write(raw_input('[GOD]MP COST: ')+'\n')
                    writfile.write(raw_input('[GOD]MENU DESC: ')+'\n')
                    writfile.close()




                if EDITCMD == 'worldpurge':
                    os.system('del /s /q c:\\Realms\\INV')
                    os.system('del /s /q c:\\Realms\\ITM')
                    os.system('del /s /q c:\\Realms\\LOC')
                    os.system('del /s /q c:\\Realms\\NPC')
                    os.system('del /s /q c:\\Realms\\SAV')
                    os.system('del /s /q c:\\Realms\\ENM')
                    os.system('del /s /q c:\\Realms\\EVT')
                    print ('[GOD] The world has been purged.')
                    GENERATEORIGIN()
                    global playerY
                    playerY = 0
                    global playerX
                    playerX = 0
                    BoolFalse()
                    EDITCMD = godcommand
                    
                if EDITCMD == godcommand:
                    EDITCMD = ''
                    MELOFF()
                    SCREENCLEAR()
                    print ('Godmode Off.')
                    
                if EDITCMD == 'allcontent':
                    os.system('tree /f c:\\realms')
                if EDITCMD == 'allweapons':
                    os.system('dir c:\\realms\\ITM\\*.atk')
                if EDITCMD == 'allitems':
                    os.system('dir c:\\realms\\ITM\\*.itm')
                if EDITCMD == 'allskills':
                    os.system('dir c:\\realms\\ITM\\*.skl')
                if EDITCMD == 'allenemies':
                    os.system('dir c:\\realms\\ENM')
                if EDITCMD == 'allevents':
                    os.system('dir c:\\realms\\EVT')
                    
                if EDITCMD == 'allareas':
                    print (' ')
                    asps = []
                    for root, dirs, files in os.walk('C:\\Realms\\LOC'):
                        for file in files:
                            if file.endswith('.loc'):
                                asps.append(file)
                    for y in asps:
                        LOCdata = ('C:\Realms\LOC\\'+str(y))
                        with open(LOCdata) as f:
                            content = f.readlines()
                            content = [x.strip('\n') for x in content]
                            AREANAME = content[0]
                            print (' '+str(y)+' - '+AREANAME)
                    print (' ')
                if EDITCMD == 'worldlist':
                    os.system ('dir C:\\Realms\\Worlds')
                    
                if EDITCMD == 'worldload':
                    WORLDNAME = raw_input('[GOD]NAME: ')
                    os.system('del /s /q c:\\Realms\\INV')
                    os.system('del /s /q c:\\Realms\\ITM')
                    os.system('del /s /q c:\\Realms\\LOC')
                    os.system('del /s /q c:\\Realms\\NPC')
                    os.system('del /s /q c:\\Realms\\SAV')
                    os.system('del /s /q c:\\Realms\\ENM')
                    os.system('del /s /q c:\\Realms\\EVT')  
                    os.system ('copy C:\\Realms\\Worlds\\'+WORLDNAME+'\\INV C:\\Realms\\INV ')
                    os.system ('copy C:\\Realms\\Worlds\\'+WORLDNAME+'\\ITM C:\\Realms\\ITM ')
                    os.system ('copy C:\\Realms\\Worlds\\'+WORLDNAME+'\\LOC C:\\Realms\\LOC ')
                    os.system ('copy C:\\Realms\\Worlds\\'+WORLDNAME+'\\NPC C:\\Realms\\NPC ')
                    os.system ('copy C:\\Realms\\Worlds\\'+WORLDNAME+'\\SAV C:\\Realms\\SAV ')
                    os.system ('copy C:\\Realms\\Worlds\\'+WORLDNAME+'\\ENM C:\\Realms\\ENM ')
                    os.system ('copy C:\\Realms\\Worlds\\'+WORLDNAME+'\\EVT C:\\Realms\\EVT ')
                    BoolFalse()
                    EDITCMD = godcommand
                    
                if EDITCMD == 'worldtoss':
                    WORLDNAME = raw_input('[GOD]NAME: ')
                    os.system ('rmdir /s /q C:\\Realms\\Worlds\\'+WORLDNAME)
                    
                if EDITCMD == 'worldsave':
                    WORLDNAME = raw_input('[GOD]NAME: ')
                    os.system ('mkdir C:\\Realms\\Worlds\\'+WORLDNAME+'\\ENM')
                    os.system ('mkdir C:\\Realms\\Worlds\\'+WORLDNAME+'\\EVT')
                    os.system ('mkdir C:\\Realms\\Worlds\\'+WORLDNAME+'\\INV')
                    os.system ('mkdir C:\\Realms\\Worlds\\'+WORLDNAME+'\\ITM')
                    os.system ('mkdir C:\\Realms\\Worlds\\'+WORLDNAME+'\\LOC')
                    os.system ('mkdir C:\\Realms\\Worlds\\'+WORLDNAME+'\\NPC')
                    os.system ('mkdir C:\\Realms\\Worlds\\'+WORLDNAME+'\\SAV')
                    os.system ('copy C:\\Realms\\ENM C:\\Realms\\Worlds\\'+WORLDNAME+'\\ENM')
                    os.system ('copy C:\\Realms\\EVT C:\\Realms\\Worlds\\'+WORLDNAME+'\\EVT')
                    os.system ('copy C:\\Realms\\INV C:\\Realms\\Worlds\\'+WORLDNAME+'\\INV')
                    os.system ('copy C:\\Realms\\ITM C:\\Realms\\Worlds\\'+WORLDNAME+'\\ITM')
                    os.system ('copy C:\\Realms\\LOC C:\\Realms\\Worlds\\'+WORLDNAME+'\\LOC')
                    os.system ('copy C:\\Realms\\NPC C:\\Realms\\Worlds\\'+WORLDNAME+'\\NPC')
                    os.system ('copy C:\\Realms\\SAV C:\\Realms\\Worlds\\'+WORLDNAME+'\\SAV')


                if EDITCMD == 'charedit':
                    print ( ' ATTRIBUTES ' )
                    playerstr = raw_input('[GOD]STRENGTH: ')
                    playerluk = raw_input('[GOD]LUCK: ')
                    playerdex = raw_input('[GOD]DEXTERITY: ')
                    playercha = raw_input('[GOD]CHARISMA: ')
                    playerint = raw_input('[GOD]INTELLIGENCE: ')
                    playercash = raw_input('[GOD]MONEY: ')
                    playerlvl = raw_input('[GOD]LEVEL: ')
                    playermaxhealth = raw_input('[GOD]MAXHEALTH: ')
                    playerhealth = raw_input('[GOD]HEALTH: ')
                    playermaxmana = raw_input('[GOD]MAXMANA: ')
                    playermana = raw_input('[GOD]MANA: ')
                if EDITCMD == 'setcash':
                    playercash = raw_input('[GOD] $')
                if EDITCMD == 'newitem':
                    NEWNAME = raw_input('[GOD]ITEMNAME: ')
                    writfile = open('C:\\Realms\\ITM\\'+NEWNAME+'.itm', "w")
                    CLASS = raw_input('[OPTIONS]ITEM,POTION,KEY,WEAPON,ARMOR: ')
                    writfile.write(str(CLASS) +'\n')
                    print('[OPTIONS] playerstr, playerluk, playerdex, playercha, playerint')
                    print('[OPTIONS] playermaxmana, playermaxhealth, none')
                    print ('[OPTIONS] POTION ONLY: bagexpand, skillbook, playercash, playerlvl')
                    print ('[OPTIONS] POTION ONLY: playerhealth,  playermana, teleport')
                    print ('[OPTIONS] WEAPON ONLY: souledge, pierce, healthleech, manaleech')
                    writfile.write(raw_input('[OPTIONS]AFFECTED STAT: ') +'\n')
                    writfile.write(raw_input('[OPTIONS]STAT CHANGE: ') +'\n')
                    print ('[OPTIONS]DESCRIPTION: ')
                    ITEMDESC = raw_input('')
                    writfile.write(ITEMDESC +'\n')
                    writfile.write(raw_input('[OPTIONS]DAMAGE: ') +'\n')
                    writfile.write(raw_input('[OPTIONS]DEFENSE: ') +'\n')
                    writfile.write(raw_input('[OPTIONS]KEY TO: ') +'\n')
                    writfile.write(raw_input('[OPTIONS]VALUE: ') +'\n')
                    writfile.close()
                    if CLASS == 'weapon':
                        writfile = open('C:\\Realms\\ITM\\'+NEWNAME+'.atk', "w")    
                        writfile.write(raw_input('[OPTIONS]ATK1: ') +'\n')
                        writfile.write(raw_input('[OPTIONS]ATK2: ') +'\n')
                        writfile.write(raw_input('[OPTIONS]ATK3: ') +'\n')
                        writfile.write(raw_input('[OPTIONS]ATK4: ') +'\n')
                        writfile.write(raw_input('[OPTIONS]ATK5: ') +'\n')
                        writfile.close()
                        
                if EDITCMD == 'destroycompanion':
                    CHAR = raw_input('[GOD]CHAR: ')
                    os.system('del /s /q C:\\Realms\\NPC\\'+CHAR+'.npc')
                    os.system('del /s /q C:\\Realms\\NPC\\'+CHAR+'.inv')
                    os.system('del /s /q C:\\Realms\\NPC\\'+CHAR+'.gos')

                if EDITCMD == 'allcompanions':
                    os.system('dir c:\\realms\\NPC\\*.npc')

                if EDITCMD == 'newcompanion':
                    COMPNAME = raw_input('[GOD]NAME: ')
                    writfile = open('C:\\Realms\\NPC\\'+COMPNAME+'.npc', "w")
                    print ('[OPTIONS] power of companions normal attack')
                    writfile.write(raw_input('[GOD]Attack: ') +'\n')
                    print ('[OPTIONS] defense number used when comp is hit')
                    writfile.write(raw_input('[GOD]Defense: ') +'\n')
                    print ('[OPTIONS] Inventory capacity of companion.')
                    writfile.write(raw_input('[GOD]Capacity: ') +'\n')
                    print ('[OPTIONS] Description read when companion is idle nearby')
                    writfile.write(raw_input('') +'\n')
                    print ('[OPTIONS] Description read when companion is hired')
                    writfile.write(raw_input('') +'\n')
                    print ('[OPTIONS] Description read when companion is fired')
                    writfile.write(raw_input('') +'\n')
                    print ('[OPTIONS] Health of companion when hired')
                    writfile.write(raw_input('[GOD]Health: ') +'\n')
                    print ('[OPTIONS] Max health of companion')
                    writfile.write(raw_input('[GOD]MaxHealth: ') +'\n')
                    print ('[OPTIONS] Skill companion will use if player')
                    print ('          is below health threshold limit.')
                    print ('          can also use \'none\'.')
                    writfile.write(raw_input('[GOD]HealSkill: ') +'\n')
                    print ('[OPTIONS] If player health falls below this')
                    print ('          companion will use above skill.')
                    writfile.write(raw_input('[GOD]HealThreshold: ') +'\n')
                    print ('[OPTIONS] Standard attack text readouts.')
                    print ('[OPTIONS] Companion has a chance to use this')
                    print ('          skill as it attacks. Can use \'none\'.')
                    writfile.write(raw_input('[GOD]AtkSkill: ') +'\n')
                    print ('[OPTIONS] % chance that an attack will result in')
                    print ('            companion using assigned skill.')
                    writfile.write(raw_input('[GOD]AtkSkillChance: ') +'\n')
                    writfile.write(raw_input('[OPTIONS]ATK1: ') +'\n')
                    writfile.write(raw_input('[OPTIONS]ATK2: ') +'\n')
                    writfile.write(raw_input('[OPTIONS]ATK3: ') +'\n')
                    writfile.write(raw_input('[OPTIONS]ATK4: ') +'\n')
                    writfile.write(raw_input('[OPTIONS]ATK5: ') +'\n')
                    writfile.close()
                    writfile = open('C:\\Realms\\NPC\\'+COMPNAME+'.inv', "w")
                    writfile.close()
                    writfile = open('C:\\Realms\\NPC\\'+COMPNAME+'.gos', "w")
                    def GOSSIPONN():
                        global frootNet6
                        frootNet6 = False
                    def GOSSIPOFFF():
                        global frootNet6
                        frootNet6 = True
                    print ('[OPTIONS] A random line in this file will appear in every area,')
                    print ('[OPTIONS] for your companion to read out as you walk around.')
                    print ('[OPTIONS] Add as many lines as you want, enter after each.')
                    print ('[OPTIONS] Enter DONE to finish creating companion gossip.')
                    GOSSIPONN()
                    while frootNet6 == False:
                        NEWLINE = raw_input('')
                        if NEWLINE == 'DONE':
                            writfile.close()
                            print ('[GOD] Companion '+str(COMPNAME)+' has been created!')
                            GOSSIPOFFF()
                        else:
                            writfile.write(NEWLINE +'\n')


                if EDITCMD == 'newenemy':
                    writfile = open('C:\\Realms\\ENM\\'+raw_input('[GOD]NAME: ')+'.enm', "w")
                    print ('[GOD]AREA DESCRIPTION: ')
                    writfile.write(raw_input('') +'\n')
                    writfile.write(raw_input('[OPTIONS]ATK1: ') +'\n')
                    writfile.write(raw_input('[OPTIONS]ATK2: ') +'\n')
                    writfile.write(raw_input('[OPTIONS]ATK3: ') +'\n')
                    writfile.write(raw_input('[OPTIONS]ATK4: ') +'\n')
                    writfile.write(raw_input('[OPTIONS]ATK5: ') +'\n')
                    writfile.write(raw_input('[OPTIONS]HIT1: ') +'\n')
                    writfile.write(raw_input('[OPTIONS]HIT2: ') +'\n')
                    writfile.write(raw_input('[OPTIONS]HIT3: ') +'\n')
                    writfile.write(raw_input('[OPTIONS]HIT4: ') +'\n')
                    writfile.write(raw_input('[OPTIONS]HIT5: ') +'\n')
                    writfile.write(raw_input('[OPTIONS]HEALTH: ') +'\n')
                    writfile.write(raw_input('[OPTIONS]ATTACK: ') +'\n')
                    writfile.write(raw_input('[OPTIONS]DEFENSE: ') +'\n')
                    ITEMCHECK = raw_input('[OPTIONS]DROPITEM: ')
                    try:
                        open('C:\\realms\\ITM\\'+ ITEMCHECK +'.itm')
                        writfile.write(ITEMCHECK +'\n')
                    except:
                        print ('[GOD] No item by that name exists. Setting drop to none.')
                        writfile.write('none\n')
                    print ('[OPTIONS] between 0 and 100% chance.')
                    writfile.write(raw_input('[OPTIONS]SKILLCHANCE: ') +'\n')
                    print ('[OPTIONS] skillname, none')
                    writfile.write(raw_input('[OPTIONS]SKILL: ') +'\n')
                    writfile.close()
                    
                if EDITCMD == 'newgossip':
                    NORTHQ = int(playerY)+1
                    SOUTHQ = int(playerY)-1
                    EASTQ = int(playerX)+1
                    WESTQ = int(playerX)-1
                    CANNORTH = ('c:\\realms\\loc\\'+str(playerX)+' '+str(NORTHQ)+'.loc')
                    CANSOUTH = ('c:\\realms\\loc\\'+str(playerX)+' '+str(SOUTHQ)+'.loc')
                    CANEAST = ('c:\\realms\\loc\\'+str(EASTQ)+' '+str(playerY)+'.loc')
                    CANWEST = ('c:\\realms\\loc\\'+str(WESTQ)+' '+str(playerY)+'.loc')
                    print ('[GOD]Input coords, a direction, or \'here\'.')
                    NEWCOORDS = raw_input('[GOD]SPAWN: ')
                    if NEWCOORDS == 'here':
                        NEWCOORDS = (str(playerX)+' '+str(playerY))
                    if NEWCOORDS == 'north':
                        NEWCOORDS = (str(playerX)+' '+str(NORTHQ))
                    if NEWCOORDS == 'south':
                        NEWCOORDS = (str(playerX)+' '+str(SOUTHQ))
                    if NEWCOORDS == 'east':
                        NEWCOORDS = (str(EASTQ)+' '+str(playerY))
                    if NEWCOORDS == 'west':
                        NEWCOORDS = (str(WESTQ)+' '+str(playerY))
                    writfile = open('C:\\Realms\\INV\\'+NEWCOORDS+'.gos', "w")
                    def GOSSIPON():
                        global frootNet5
                        frootNet5 = False
                    def GOSSIPOFF():
                        global frootNet5
                        frootNet5 = True
                    print ('[OPTIONS] Add as many lines as you want, enter after each.')
                    print ('[OPTIONS] Enter DONE to finish creating gossip.')
                    GOSSIPON()
                    while frootNet5 == False:
                        NEWLINE = raw_input('')
                        if NEWLINE == 'DONE':
                            writfile.close()
                            print ('[GOD] Gossip created at '+str(playerX)+' '+str(playerY)+'!')
                            GOSSIPOFF()
                        else:
                            writfile.write(NEWLINE +'\n')


                if EDITCMD == 'newstatcheck':
                    NORTHQ = int(playerY)+1
                    SOUTHQ = int(playerY)-1
                    EASTQ = int(playerX)+1
                    WESTQ = int(playerX)-1
                    CANNORTH = ('c:\\realms\\loc\\'+str(playerX)+' '+str(NORTHQ)+'.loc')
                    CANSOUTH = ('c:\\realms\\loc\\'+str(playerX)+' '+str(SOUTHQ)+'.loc')
                    CANEAST = ('c:\\realms\\loc\\'+str(EASTQ)+' '+str(playerY)+'.loc')
                    CANWEST = ('c:\\realms\\loc\\'+str(WESTQ)+' '+str(playerY)+'.loc')
                    print ('[GOD]Input coords, a direction, or \'here\'.')
                    NEWCOORDS = raw_input('[GOD]SPAWN: ')
                    if NEWCOORDS == 'here':
                        NEWCOORDS = (str(playerX)+' '+str(playerY))
                    if NEWCOORDS == 'north':
                        NEWCOORDS = (str(playerX)+' '+str(NORTHQ))
                    if NEWCOORDS == 'south':
                        NEWCOORDS = (str(playerX)+' '+str(SOUTHQ))
                    if NEWCOORDS == 'east':
                        NEWCOORDS = (str(EASTQ)+' '+str(playerY))
                    if NEWCOORDS == 'west':
                        NEWCOORDS = (str(WESTQ)+' '+str(playerY))
                    writfile = open('C:\\Realms\\INV\\'+NEWCOORDS+'.chk', "w")
                    print ('[OPTIONS] str, luk, dex, int, cha, lvl')
                    writfile.write(raw_input('[GOD]STAT: ') +'\n')
                    print ('[OPTIONS] Stat must be this or higher to pass the check')
                    writfile.write(raw_input('[GOD]NUMBER: ') +'\n')
                    print ('[OPTIONS] Name of event to run if check passes.')
                    writfile.write(raw_input('[GOD]EVENT: ') +'\n')
                    print ('[OPTIONS] Name of event to run if check fails, or \'none\'.')
                    writfile.write(raw_input('[GOD]EVENT: ') +'\n')
                    print ('[OPTIONS] Does the check repeat if passed, yes or no')
                    writfile.write(raw_input('[GOD]REPEAT: ') +'\n')
                    print ('[OPTIONS] Does the check repeat if failed, yes or no')
                    writfile.write(raw_input('[GOD]REPEAT: ') +'\n')
                    writfile.close()
                    print ('[GOD] Stat check created at '+str(playerX)+' '+str(playerY)+'!')



                if EDITCMD == 'newarea':
                    NORTHQ = int(playerY)+1
                    SOUTHQ = int(playerY)-1
                    EASTQ = int(playerX)+1
                    WESTQ = int(playerX)-1
                    CANNORTH = ('c:\\realms\\loc\\'+str(playerX)+' '+str(NORTHQ)+'.loc')
                    CANSOUTH = ('c:\\realms\\loc\\'+str(playerX)+' '+str(SOUTHQ)+'.loc')
                    CANEAST = ('c:\\realms\\loc\\'+str(EASTQ)+' '+str(playerY)+'.loc')
                    CANWEST = ('c:\\realms\\loc\\'+str(WESTQ)+' '+str(playerY)+'.loc')
                    print ('[GOD]Input either coords or a direction for the area.')
                    NEWCOORDS = raw_input('[GOD]COORDINATES: ')
                    if NEWCOORDS == 'north':
                        NEWCOORDS = (str(playerX)+' '+str(NORTHQ))
                    if NEWCOORDS == 'south':
                        NEWCOORDS = (str(playerX)+' '+str(SOUTHQ))
                    if NEWCOORDS == 'east':
                        NEWCOORDS = (str(EASTQ)+' '+str(playerY))
                    if NEWCOORDS == 'west':
                        NEWCOORDS = (str(WESTQ)+' '+str(playerY))
                        
                    writfile = open('C:\\Realms\\LOC\\'+NEWCOORDS+'.loc', "w")
                    writfile.write(raw_input('[GOD]NAME: ') +'\n')
                    print ('[GOD]LOCAL DESCRIPTION:')
                    writfile.write(raw_input('') +'\n')
                    writfile.write(raw_input('[GOD]MAPDESC: ') +'\n')
                    LOCKD = raw_input('[GOD]LOCKED: ')
                    if LOCKD != 'yes':
                        print ('[GOD] Lock value isn\'t yes, setting to no')
                        LOCKD = 'no'
                    writfile.write(LOCKD)
                    writfile.close()
                    
                if EDITCMD == 'newevent':
                    writfile = open('C:\\Realms\\EVT\\'+raw_input('[GOD]NAME: ')+'.eve', "w")
                    print ('[GOD]DESC: ')
                    writfile.write(raw_input('') +'\n')
                    print ('[OPTIONS] dropitem, spawnenemy, spawnevent')
                    print ('[OPTIONS] heal, hurt, teleport, spawncompanion, none')
                    writfile.write(raw_input('[GOD]TAG: ') +'\n')
                    print ('[OPTIONS] name, number, none')
                    writfile.write(raw_input('[GOD]TAG VALUE: ') +'\n')
                    print ('[OPTIONS] yes, no')
                    writfile.write(raw_input('[GOD]REPEAT: ') +'\n')
                    print ('[OPTIONS] coordinates, currentarea')
                    writfile.write(raw_input('[GOD]COORDS: ') +'\n')
                    print ('[OPTIONS] before, after')
                    writfile.write(raw_input('[GOD]SETTING: ')+'\n')
                    writfile.close()

                if EDITCMD == 'player spawnitem':
                    ITEMCHECK = raw_input('[GOD]ITEM:')
                    try:
                        open('C:\\realms\\ITM\\'+ ITEMCHECK +'.itm')
                        playerinventory.insert(0,ITEMCHECK)
                        print ('[GOD] '+ITEMCHECK+' spawned on player.')
                        playerinvnumber = int(playerinvnumber) + 1
                    except:
                        print ('[GOD] No item by that name exists.')      

                if EDITCMD == 'area spawnitem':
                    ITEMCHECK = raw_input('[GOD]ITEM:')
                    try:
                        open('C:\\realms\\ITM\\'+ ITEMCHECK +'.itm')
                        localinventory.insert(0,ITEMCHECK)
                        print ('[GOD] '+ITEMCHECK+' spawned at '+str(playerX)+','+str(playerY))
                    except:
                        print ('[GOD] No item by that name exists.')

                if EDITCMD == 'fullheal':
                    playerhealth = playermaxhealth
                    playermana = playermaxmana
                    print ('[GOD] All healed up!')

                if EDITCMD == 'spawncompanion':
                    ENEM = raw_input('[GOD]NAME: ')
                    try:
                        open('C:\\Realms\\NPC\\'+ ENEM +'.npc')
                        NORTHQ = int(playerY)+1
                        SOUTHQ = int(playerY)-1
                        EASTQ = int(playerX)+1
                        WESTQ = int(playerX)-1
                        CANNORTH = ('c:\\realms\\loc\\'+str(playerX)+' '+str(NORTHQ)+'.loc')
                        CANSOUTH = ('c:\\realms\\loc\\'+str(playerX)+' '+str(SOUTHQ)+'.loc')
                        CANEAST = ('c:\\realms\\loc\\'+str(EASTQ)+' '+str(playerY)+'.loc')
                        CANWEST = ('c:\\realms\\loc\\'+str(WESTQ)+' '+str(playerY)+'.loc')
                        print ('[GOD]OPTIONS: area coordinates, \'here\' for current area, compass direction.')
                        NEWCOORDS = raw_input('[GOD]AREA: ')
                        if NEWCOORDS == 'here':
                            NEWCOORDS = (str(playerX)+' '+str(playerY))
                        if NEWCOORDS == 'north':
                            NEWCOORDS = (str(playerX)+' '+str(NORTHQ))
                        if NEWCOORDS == 'south':
                            NEWCOORDS = (str(playerX)+' '+str(SOUTHQ))
                        if NEWCOORDS == 'east':
                            NEWCOORDS = (str(EASTQ)+' '+str(playerY))
                        if NEWCOORDS == 'west':
                            NEWCOORDS = (str(WESTQ)+' '+str(playerY))
                        ENEMC = NEWCOORDS
                        try:
                            open('C:\\realms\\INV\\'+ENEMC+'.cmp')
                            writfile = open('C:\\realms\\INV\\'+ENEMC+'.cmp', "a")
                            writfile.write(ENEM+'\n')
                            writfile.close()
                            print ('[GOD] '+ENEM+' spawned at '+str(ENEMC))
                        except:
                            open('C:\\realms\\INV\\'+ENEMC+'.cmp', "w").close()
                            open('C:\\realms\\INV\\'+ENEMC+'.cmp')
                            writfile = open('C:\\realms\\INV\\'+ENEMC+'.cmp', "a")
                            writfile.write(ENEM+'\n')
                            writfile.close()
                            print ('[GOD] '+ENEM+' spawned at '+str(ENEMC))
                    except:
                        print ('[GOD] No companion by that name exists.')



                if EDITCMD == 'spawnevent':
                    ENEM = raw_input('[GOD]NAME: ')
                    try:
                        open('C:\\Realms\\EVT\\'+ ENEM +'.eve')
                        NORTHQ = int(playerY)+1
                        SOUTHQ = int(playerY)-1
                        EASTQ = int(playerX)+1
                        WESTQ = int(playerX)-1
                        CANNORTH = ('c:\\realms\\loc\\'+str(playerX)+' '+str(NORTHQ)+'.loc')
                        CANSOUTH = ('c:\\realms\\loc\\'+str(playerX)+' '+str(SOUTHQ)+'.loc')
                        CANEAST = ('c:\\realms\\loc\\'+str(EASTQ)+' '+str(playerY)+'.loc')
                        CANWEST = ('c:\\realms\\loc\\'+str(WESTQ)+' '+str(playerY)+'.loc')
                        print ('[GOD]OPTIONS: area coordinates, \'here\' for current area, compass direction.')
                        NEWCOORDS = raw_input('[GOD]AREA: ')
                        if NEWCOORDS == 'here':
                            NEWCOORDS = (str(playerX)+' '+str(playerY))
                        if NEWCOORDS == 'north':
                            NEWCOORDS = (str(playerX)+' '+str(NORTHQ))
                        if NEWCOORDS == 'south':
                            NEWCOORDS = (str(playerX)+' '+str(SOUTHQ))
                        if NEWCOORDS == 'east':
                            NEWCOORDS = (str(EASTQ)+' '+str(playerY))
                        if NEWCOORDS == 'west':
                            NEWCOORDS = (str(WESTQ)+' '+str(playerY))
                        ENEMC = NEWCOORDS
                        try:
                            open('C:\\realms\\INV\\'+ENEMC+'.eve')
                            writfile = open('C:\\realms\\INV\\'+ENEMC+'.eve', "a")
                            writfile.write(ENEM+'\n')
                            writfile.close()
                            print ('[GOD] '+ENEM+' spawned at '+str(ENEMC))
                        except:
                            open('C:\\realms\\INV\\'+ENEMC+'.eve', "w").close()
                            open('C:\\realms\\INV\\'+ENEMC+'.eve')
                            writfile = open('C:\\realms\\INV\\'+ENEMC+'.eve', "a")
                            writfile.write(ENEM+'\n')
                            writfile.close()
                            print ('[GOD] '+ENEM+' spawned at '+str(ENEMC))
                    except:
                        print ('[GOD] No event by that name exists.')
                        
                if EDITCMD == 'spawnenemy':
                    ENEM = raw_input('[GOD]NAME: ')
                    try:
                        open('C:\\Realms\\ENM\\'+ ENEM +'.enm')
                        NORTHQ = int(playerY)+1
                        SOUTHQ = int(playerY)-1
                        EASTQ = int(playerX)+1
                        WESTQ = int(playerX)-1
                        CANNORTH = ('c:\\realms\\loc\\'+str(playerX)+' '+str(NORTHQ)+'.loc')
                        CANSOUTH = ('c:\\realms\\loc\\'+str(playerX)+' '+str(SOUTHQ)+'.loc')
                        CANEAST = ('c:\\realms\\loc\\'+str(EASTQ)+' '+str(playerY)+'.loc')
                        CANWEST = ('c:\\realms\\loc\\'+str(WESTQ)+' '+str(playerY)+'.loc')
                        print ('[GOD]OPTIONS: area coordinates, \'here\' for current area, compass direction.')
                        NEWCOORDS = raw_input('[GOD]AREA: ')
                        if NEWCOORDS == 'here':
                            NEWCOORDS = (str(playerX)+' '+str(playerY))
                        if NEWCOORDS == 'north':
                            NEWCOORDS = (str(playerX)+' '+str(NORTHQ))
                        if NEWCOORDS == 'south':
                            NEWCOORDS = (str(playerX)+' '+str(SOUTHQ))
                        if NEWCOORDS == 'east':
                            NEWCOORDS = (str(EASTQ)+' '+str(playerY))
                        if NEWCOORDS == 'west':
                            NEWCOORDS = (str(WESTQ)+' '+str(playerY))
                        ENEMC = NEWCOORDS
                        try:
                            open('C:\\realms\\INV\\'+ENEMC+'.enm')
                            writfile = open('C:\\realms\\INV\\'+ENEMC+'.enm', "a")
                            writfile.write(ENEM+'\n')
                            writfile.close()
                            print ('[GOD] '+ENEM+' spawned at '+str(ENEMC))
                        except:
                            open('C:\\realms\\INV\\'+ENEMC+'.enm', "w").close()
                            open('C:\\realms\\INV\\'+ENEMC+'.enm')
                            writfile = open('C:\\realms\\INV\\'+ENEMC+'.enm', "a")
                            writfile.write(ENEM+'\n')
                            writfile.close()
                            print ('[GOD] '+ENEM+' spawned at '+str(ENEMC))
                    except:
                        print ('[GOD] No enemy by that name exists.')

                if EDITCMD == 'help items':
                    print ('    ')
                    print ('    Items include every weapon, armor, key, potion')
                    print ('    and useless drop present in the world. Equipable')
                    print ('    items can be enchanted to increase stats or with')
                    print ('    special preset effects, such as pierce. ')
                    print ('    To create an item that teaches a skill, you must')
                    print ('    create a potion with the \'skillbook\' tag, then')
                    print ('    set the effect value to the name of the skill.')
                    print ('    anything that you want to be a one time use')
                    print ('    item should be classified as a potion.')
                    print ('    items with the regular \'item\' tag, when used')
                    print ('    in combat, will be thrown for whatever the damage')
                    print ('    tag of the item is, handy for throwing knifes and such.')
                    print ('    ')

                if EDITCMD == 'help areas':
                    print ('    Areas are arranged in a coordinate system, and')
                    print ('    filenames reflect the coordinate value of the area.')
                    print ('    0 0 is the default starting area for a new character')
                    print ('    in any world.')
                    print ('    Areas are processed in layers once entered. The first')
                    print ('    thing that is ran is a statcheck, if there is one.')
                    print ('    Next, any events with a before tag are ran.')
                    print ('    Then the location description is read, and after that')
                    print ('    any events present with an \'after\' tag are ran.')
                    print ('    Then, any enemies in the area will read their descriptions.')
                    print ('    A handy tip: Using the edit command and entering the')
                    print ('    coordinates of an area, will open every file associated')
                    print ('    with that space. That includes any events, the items list,')
                    print ('    the enemies list, merchants, gossip, everything. This is')
                    print ('    the quickest way to modify a complicated area.')
                    print ('    If an area is set to locked, it will be inaccessible until')
                    print ('    a key is used in an adjacent area that is set up to')
                    print ('    unlock it with the correct coordinates. ')
                if EDITCMD == 'help skills':
                    print ('    Skills can be learned by players or enemies. For a player')
                    print ('    to be able to use a skill, they need to use a potion that')
                    print ('    has the skillbook tag.')
                    print ('    For enemy skills, no need to worry about MP, they have')
                    print ('    an unlimited amount, and instead rely on a random number')
                    print ('    to decide if they cast it or not.')
                    print ('    Each skill can have up to 3 effects, which range from')
                    print ('    helping or hurting the casters stats, debuffing the target,')
                    print ('    convering health to mp and vice versa, stunning the target,')
                    print ('    and so on. The descriptions for each effect are what the')
                    print ('    caster reads as that effect happens.')
                if EDITCMD == 'help enemies':
                    print ('    Enemies are any hostile thing that can attack you when you')
                    print ('    are in the same area. If you intend to make an enemy, it\'s')
                    print ('    a good idea to make any drops and skills they will be using')
                    print ('    beforehand, or in a separate window. ')
                    print ('    Skillchance is the % of turns that the enemy will use their')
                    print ('    skill. ATK text is what the enemies read as they do standard attacks.')
                    print ('    HIT text is what they read as they take damage.')
                if EDITCMD == 'help events':
                    print ('    Events can be used to create a wide range of situational content.')
                    print ('    Each area can potentially hold 2 events at once, one tagged before')
                    print ('    and one tagged after, so this system allows for branching storylines')
                    print ('    and all kinds of neat possibilities if used well. Important to note that')
                    print ('    teleport events MUST be tagged as before, so the new area description is')
                    print ('    displayed as you enter it. Since events tagged after only happen after')
                    print ('    the area description, teleporting like that is glitchy and not worth using.')
                    print ('    events tagged heal, will restore both health and mana by whatever the')
                    print ('    tag value is. Note that events must be SPAWNED after they are created.')
                    print ('    Events, like items, are not tied directly to any specific area until they')
                    print ('    are placed there.')
                if EDITCMD == 'help gossip':
                    print ('    gossip is a simple random message system that can be placed in any area.')
                    print ('    Upon entering an area that has gossip, a random line of the gossip file ')
                    print ('    will be displayed at the bottom. This is a fantastic way to breathe a bit')
                    print ('    more varieties into your maps, and to point players towards interesting')
                    print ('    stuff. Remember to use tab to format your text when making a gossip file,')
                    print ('    because pressing ENTER will create a new gossip entry, not a new line.')
                    print ('    TAB can be used to create entire paragraphs in individual lines in the file.')
                if EDITCMD == 'help merchants':
                    print ('    Merchants are area specific item traders. Each merchant is able to hold up')
                    print ('    to 10 items. Any unused item slots when creating a merchant file should be')
                    print ('    filled with a 0. Its always good to remind the player with gossip that a ')
                    print ('    trader is nearby, because there is no automatic notifiaction that they are')
                    print ('    present when you enter an area. Or you could think ahead and mention it in')
                    print ('    the area description.')
                if EDITCMD == 'help statchecks':
                    print ('atat checks are little switches that will show 2 different events, depending')
                    print ('on the value of a stat of your choosing. For example, you could set it so that')
                    print ('if the player is level 5, an event appears that spawns a key. But if the player')
                    print ('isn\'t at that high level, the player is told to go train. Make the events')
                    print ('before you make the statcheck.')
                if EDITCMD == 'help':
                    print (' ')
                    print ('                  help items = Learn about items.')
                    print ('                  help areas = Learn about areas.')
                    print ('                 help skills = Learn about skills.')
                    print ('                help enemies = Learn about enemies.')
                    print ('                 help events = Learn about events.')
                    print ('                 help gossip = Learn about gossip.')
                    print ('              help merchants = Learn about merchants.')
                    print ('             help statchecks = Learn about statchecks.')
                    print ('                      setgod = Change the godmode command.')
                    print ('               =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=')
                    print ('                  allcontent = Display all game content.')
                    print ('                    allitems = Display all world items.')
                    print ('                  allweapons = Display all world weapons.')
                    print ('                    allareas = Display all world areas.')
                    print ('                   allskills = Display all world skills.')
                    print ('                  allenemies = Display all world enemies.')
                    print ('                   allevents = Display all world events.')
                    print ('                   allgossip = Display all world gossip.')
                    print ('                allmerchants = Display all world merchants.')
                    print ('               allstatchecks = Display all stat checks')
                    print ('               allcompanions = Display all companions.')
                    print ('                     newitem = Create a new item.')
                    print ('                     newarea = Create a new area.')
                    print ('                    newskill = Create a new skill.')
                    print ('                    newenemy = Create a new hostile.')
                    print ('                    newevent = Create a new event.')
                    print ('                   newgossip = Create a new chat NPC.')
                    print ('                 newmerchant = Create a new merchant.')
                    print ('                newstatcheck = Create a new stat check.')
                    print ('                newcompanion = Create a new companion.')
                    print ('                 destroyitem = Destroy an item or skill.')
                    print ('                 destroyarea = Destroy a world area.')
                    print ('                destroyskill = Destroy a world skill.')
                    print ('                destroyenemy = Destroy a world enemy.')
                    print ('                destroyevent = Destroy a world event.')
                    print ('               destroygossip = Destroy a chat NPC.')
                    print ('             destroymerchant = Destroy an area merchant.')
                    print ('            destroystatcheck = Destroy a stat check.')
                    print ('            destroycompanion = Destroy a companion.')
                    print ('            destroycharacter = Destroy a world char.')
                    print ('                        edit = Edit a raw content file.')
                    print ('                     inspect = View any world item.')
                    print ('              =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=')
                    print ('                  spawnevent = Spawn an area event.')
                    print ('                  spawnenemy = Spawn an enemy NPC.')
                    print ('              spawncompanion = Spawn a companion NPC.')
                    print ('              area spawnitem = Spawn item to area.')
                    print ('            player spawnitem = Spawn item to inventory.')
                    print ('              =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=')
                    print ('                    charedit = Edit all player stats.')
                    print ('                    fullheal = Restores HP and MP.')
                    print ('                     levelup = Player levels up.')
                    print ('                    teleport = Change player location.')
                    print ('                  learnskill = Player learns a skill.')
                    print ('                  setbagsize = Set inventory capacity.')
                    print ('                     setcash = Set players money.')
                    print ('                setcompanion = Set player companion.')
                    print ('              =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=')
                    print ('                  exportchar = Save player to any world.')
                    print ('                    viewroot = View the realms directory.')
                    print ('                  viewsource = View the realms source code.')
                    print ('                   worldsave = Create a world backup.')
                    print ('                  worldpurge = Start a brand new world.')
                    print ('                   worldload = Load a world backup.')
                    print ('                   worldtoss = Delete a world backup.')
                    print ('                   worldlist = List all world backups.')     
                    print (' ')

#######END CREATOR CONSOLE
        if command == 'w':
            command = 'walk'
        if command == 'walk':

            
            FIGHTSKIP = 1
            NORTHQ = int(playerY)+1
            SOUTHQ = int(playerY)-1
            EASTQ = int(playerX)+1
            WESTQ = int(playerX)-1
            CANNORTH = ('c:\\realms\\loc\\'+str(playerX)+' '+str(NORTHQ)+'.loc')
            CANSOUTH = ('c:\\realms\\loc\\'+str(playerX)+' '+str(SOUTHQ)+'.loc')
            CANEAST = ('c:\\realms\\loc\\'+str(EASTQ)+' '+str(playerY)+'.loc')
            CANWEST = ('c:\\realms\\loc\\'+str(WESTQ)+' '+str(playerY)+'.loc')
            WALKDIR = raw_input('['+playername+'] Direction: ')
            if WALKDIR == 'n':
                WALKDIR = 'north'
            if WALKDIR == 'north':
                try:
##########LOCK FUNCTION TESTING#####################
                    open(CANNORTH)
                    MAP1data = (CANNORTH)
                    with open(MAP1data) as f:
                        mapcontent1 = f.readlines()
                        mapcontent1 = [x.strip('\n') for x in mapcontent1]
                    LOCKED = mapcontent1[3]
                    if LOCKED != 'yes':
###################################################
                    
                        open(CANNORTH)
                        open('C:\\Realms\\INV\\'+str(playerX)+' '+str(playerY)+'.inv', "w").close()
                        with open('C:\\Realms\\INV\\'+str(playerX)+' '+str(playerY)+'.inv', "w") as f:
                            for L in localinventory:
                                f.write(L + '\n')
                        global playerY
                        playerY = NORTHQ
                        gotlocation = 0
                    else:
                        print ('['+playername+'] The path is locked off. I need to use a key.')
                except:
                    print ('['+playername+'] I can\'t move in that direction.')
########REST IS ONE TAB OVER#####################
            if WALKDIR == 's':
                WALKDIR = 'south'
            if WALKDIR == 'south':
                try:
######
                    open(CANSOUTH)
                    MAP2data = (CANSOUTH)
                    with open(MAP2data) as f:
                        mapcontent2 = f.readlines()
                        mapcontent2 = [x.strip('\n') for x in mapcontent2]
                    LOCKED = mapcontent2[3]
                    if LOCKED != 'yes':
#####
                        open(CANSOUTH)
                        open('C:\\Realms\\INV\\'+str(playerX)+' '+str(playerY)+'.inv', "w").close()
                        with open('C:\\Realms\\INV\\'+str(playerX)+' '+str(playerY)+'.inv', "w") as f:
                            for L in localinventory:
                                f.write(L + '\n')
                        global playerY
                        playerY = SOUTHQ
                        gotlocation = 0
                    else:
                        print ('['+playername+'] The path is locked off. I need to use a key.')
                except:
                    print ('['+playername+'] I can\'t move in that direction.')

            if WALKDIR == 'w':
                WALKDIR = 'west'
            if WALKDIR == 'west':
                try:
###########
                    open(CANWEST)
                    MAP3data = (CANWEST)
                    with open(MAP3data) as f:
                        mapcontent3 = f.readlines()
                        mapcontent3 = [x.strip('\n') for x in mapcontent3]
                    LOCKED = mapcontent3[3]
                    if LOCKED != 'yes':
##########
                        open(CANWEST)
                        open('C:\\Realms\\INV\\'+str(playerX)+' '+str(playerY)+'.inv', "w").close()
                        with open('C:\\Realms\\INV\\'+str(playerX)+' '+str(playerY)+'.inv', "w") as f:
                            for L in localinventory:
                                f.write(L + '\n')
                        global playerX
                        playerX = WESTQ
                        gotlocation = 0
                    else:
                        print ('['+playername+'] The path is locked off. I need to use a key.')
                except:
                    print ('['+playername+'] I can\'t move in that direction.')

            if WALKDIR == 'e':
                WALKDIR = 'east'
            if WALKDIR == 'east':
                try:
##################
                    open(CANEAST)
                    MAP4data = (CANEAST)
                    with open(MAP4data) as f:
                        mapcontent4 = f.readlines()
                        mapcontent4 = [x.strip('\n') for x in mapcontent4]
                    LOCKED = mapcontent4[3]
                    if LOCKED != 'yes':
##################
                        open(CANEAST)
                        open('C:\\Realms\\INV\\'+str(playerX)+' '+str(playerY)+'.inv', "w").close()
                        with open('C:\\Realms\\INV\\'+str(playerX)+' '+str(playerY)+'.inv', "w") as f:
                            for L in localinventory:
                                f.write(L + '\n')
                        global playerX
                        playerX = EASTQ
                        gotlocation = 0
                    else:
                        print ('['+playername+'] The path is locked off. I need to use a key.')              
                except:
                    print ('['+playername+'] I can\'t move in that direction.')
                                             
        if command == 'save':
            global playerhealth
            FIGHTSKIP = 1
            open('C:\\Realms\\SAV\\'+playername+'.sav', "w").close()
            writfile = open('C:\\Realms\\SAV\\'+playername+'.sav', "w")      
            writfile.write(str(playername) +'\n')
            writfile.write(str(playerstr) +'\n')
            writfile.write(str(playerluk) +'\n')
            writfile.write(str(playerdex) +'\n')
            writfile.write(str(playercha) +'\n')
            writfile.write(str(playerint) +'\n')
            writfile.write(str(playerlvl) +'\n')
            writfile.write(str(playerexp) +'\n')
            writfile.write(str(playercash) +'\n')
            writfile.write(str(playerX) +'\n')
            writfile.write(str(playerY) +'\n')
            writfile.write(str(playerhealth) +'\n')
            writfile.write(str(playermaxhealth) +'\n')
            writfile.write(str(playerdam) +'\n')
            writfile.write(str(playerdef) +'\n')
            writfile.write(str(playerinvlimit) +'\n')
            writfile.write(str(playerinvnumber) +'\n')
            writfile.write(str(godcommand) +'\n')
            writfile.write(str(playermana) +'\n')
            writfile.write(str(playermaxmana) +'\n')
            writfile.write(str(playerwep) +'\n')
            writfile.write(str(playerarm) +'\n')
            writfile.write(str(playercomp) +'\n')
            writfile.close()


#####INVENTORY SAVER######


            open('C:\\Realms\\INV\\'+playername+'.inv', "w").close()
            with open('C:\\Realms\\INV\\'+playername+'.inv', "w") as f:
                for s in playerinventory:
                    f.write(s + '\n')
            open('C:\\Realms\\INV\\'+str(playerX)+' '+str(playerY)+'.inv', "w").close()
            with open('C:\\Realms\\INV\\'+str(playerX)+' '+str(playerY)+'.inv', "w") as f:
                for L in localinventory:
                    f.write(L + '\n')


            open('C:\\Realms\\INV\\'+playername+'.skl', "w").close()
            with open('C:\\Realms\\INV\\'+playername+'.skl', "w") as f:
                for s in playerskills:
                    f.write(s + '\n')
            if playercomp != 'none':
                open('C:\\Realms\\NPC\\'+playercomp+'.inv', "w").close()
                with open('C:\\Realms\\NPC\\'+playercomp+'.inv', "w") as f:
                    for s in compinventory:
                        f.write(s + '\n') 
###########################

            print ('['+playername+'] Progress has been saved!')
            
        if command == 'quit':
            FIGHTSKIP = 1
            BoolFalse()


####### BASIC LOGIC CHECK #########
            
        global playerhealth
        global playermaxhealth
        global playermana
        global playermaxmana
        try:
            if int(playerhealth) > int(playermaxhealth):

                playerhealth = playermaxhealth
        except:
            pass
        try:    
            if int(playermana) > int(playermaxmana):

                playermana = playermaxmana
        except:
            pass
        if int(playerhealth)<1:
           print (' ')
           print (' ')
           print ('                 '+playername+' has died.')
           print (' ')
           print (' ')
           print (' ')
           print (' ')
           print (' ')
           print (' ')
           BoolFalse()
           
########## LEVELUP LOOP ###########

        def MELON3():
            global frootNet3
            frootNet3 = False
             
        def MELOFF3():
            global frootNet3
            frootNet3 = True
            
        if int(playerexp) > int(NEXTLEVEL) or int(playerexp) == int(NEXTLEVEL):
            MELON3()
            print (' ')
            NEWLEVEL = int(playerlvl) + 1
            print ('['+playername+'] has reached level '+str(NEWLEVEL)+'!')
            while frootNet3 == False:       
                print ('['+playername+'] Focus on which stat: ')
                print('[OPTIONS]: Strength, Charisma, Dexterity, Intelligence, Luck, Health')
                STATUP = raw_input('['+playername+']: ')
                VALID = ['strength','charisma','dexterity','intelligence','luck','health','Strength','Charisma','Dexterity','Intelligence','Luck','Health']
                if STATUP in VALID:
                    
                    playerstr = int(playerstr) + 1
                    playerluk = int(playerluk) + 1
                    playerdex = int(playerdex) + 1
                    playercha = int(playercha) + 1
                    playerint = int(playerint) + 1
                    playermaxhealth = int(playermaxhealth) + 10
                    playermaxmana = int(playermaxmana) + 5
                    playerhealth = playermaxhealth
                    playermana = playermaxmana
                    
                    if STATUP == 'strength' or STATUP =='Strength':
                        playerstr = int(playerstr)+1
                        playerexp = 0
                        playerlvl = NEWLEVEL
                        print ('['+playername+'] You feel more lethal than ever.')
                        MELOFF3()
                    if STATUP == 'luck' or STATUP =='Luck':
                        playerluk = int(playerluk)+1
                        playerexp = 0
                        playerlvl = NEWLEVEL
                        print ('['+playername+'] You feel more willing to take chances.')
                        MELOFF3()
                    if STATUP == 'dexterity' or STATUP =='Dexterity':
                        playerdex = int(playerdex)+1
                        playerexp = 0
                        playerlvl = NEWLEVEL
                        print ('['+playername+'] You feel more agile.')
                        MELOFF3()
                    if STATUP == 'charisma' or STATUP =='Charisma':
                        playercha = int(playercha)+1
                        playerexp = 0
                        playerlvl = NEWLEVEL
                        print ('['+playername+'] You feel more charming and witty.')
                        MELOFF3()
                    if STATUP == 'intelligence' or STATUP =='Intelligence':
                        playerint = int(playerint)+1
                        playerexp = 0
                        playerlvl = NEWLEVEL
                        playermaxmana = int(playermaxmana) + 15
                        playermana = playermaxmana
                        print ('['+playername+'] You feel your conciousness expand.')
                        MELOFF3()
                    if STATUP == 'health' or STATUP =='Health':
                        playermaxhealth = int(playermaxhealth)+25
                        playerexp = 0
                        playerlvl = NEWLEVEL
                        print ('['+playername+'] You feel tougher.')
                        playerhealth = playermaxhealth
                        MELOFF3()
                    
                else:
                     print ('['+playername+'] Let\'s try that again.')
                


################## ENEMY INIT ############
        if FIGHTSKIP != 1:

            ##################
            ## BATTLESTAT



            ##################

            try:
                open('C:\\Realms\\INV\\'+str(playerX)+' '+str(playerY)+'.enm')
                ENMparse = ('C:\\Realms\\INV\\'+str(playerX)+' '+str(playerY)+'.enm')
                with open(ENMparse) as f:
                    enemy = f.readlines()
                    enemy = [x.strip('\n') for x in enemy]
                TARGET = enemy[0]
                ENMdata = ('C:\\Realms\\ENM\\'+str(TARGET)+'.enm')
                with open(ENMdata) as f:
                    enemyi = f.readlines()
                    enemyi = [x.strip('\n') for x in enemyi]
                    
                global ENMDESC
                global ENMHP
                global ENMATK
                global ENMDEF
                
                ENMDESC = enemyi[0]
                ENMATK1 = enemyi[1]
                ENMATK2 = enemyi[2]
                ENMATK3 = enemyi[3]
                ENMATK4 = enemyi[4]
                ENMATK5 = enemyi[5]
                ENMDEF1 = enemyi[6]
                ENMDEF2 = enemyi[7]
                ENMDEF3 = enemyi[8]
                ENMDEF4 = enemyi[9]
                ENMDEF5 = enemyi[10]
                ENMHP = enemyi[11]
                ENMATK = enemyi[12]
                ENMDEF = enemyi[13]
                ENMDROP = enemyi[14]
                ENMSKILLCHANCE = enemyi[15]
                ENMSKILL = enemyi[16]
                ENMEXP = ENMHP
                ENMstun = 0
                FIGHTCMD = 'nada'
                playerstun = 0

                
            #### COMBAT INIT #####
                global PLAYERHIT
                global PLAYERSHIELD
                PLAYERHIT = playerdam
                PLAYERSHIELD = playerdef

                if playerwep != 'empty':
                    weapon = playerwep
                    ATKdata = ('C:\\Realms\\ITM\\'+str(weapon)+'.atk')
                    with open(ATKdata) as f:
                        ATTACKS = f.readlines()
                        ATTACKS = [x.strip('\n') for x in ATTACKS]
                    PLAYERATK1 = ATTACKS[0]
                    PLAYERATK2 = ATTACKS[1]
                    PLAYERATK3 = ATTACKS[2]
                    PLAYERATK4 = ATTACKS[3]
                    PLAYERATK5 = ATTACKS[4]  
                else:
                    PLAYERATK1 = ('You run at the '+TARGET+' and attack with your bare hands!')
                    PLAYERATK2 = ('You throw a hard punch!')
                    PLAYERATK3 = ('You clench your fists and run towards the '+TARGET+' to strike!')
                    PLAYERATK4 = ('You see an opening for a hit and throw your fist at the enemy!')
                    PLAYERATK5 = ('You attack the '+TARGET+' with a bare knuckle punch!')
            ###################################
                def MELON2():
                    global frootNet2
                    frootNet2 = False
             
                def MELOFF2():
                    global frootNet2
                    frootNet2 = True    
                MELON2()
                print (' ')
                print ('['+TARGET+'] Moves to engage you in combat!')
                print (' ')
                while frootNet2 == False:
                    
    
    ##33###     FIGHT COMMAND LOOP     ##################################
                    try:
                        playerinventory.remove('')
                        playerinventory.remove('')
                        playerinventory.remove('')
                        playerinventory.remove('')
                        playerinventory.remove('')
                        playerinventory.remove('')
                        playerinventory.remove('')
                        playerinventory.remove('')
                        playerinventory.remove('')
                        playerinventory.remove('')
                        playerinventory.remove('')
                    except:
                        pass
                    try:
                        if FIGHTCMD in VALIDMOVES and SKIPTURN == 0:
                            ENMstun = int(ENMstun) - 1
                            if ENMstun < 0:
                                ENMstun = 0
                           

                    except:
                        pass
                    
                    SKIPTURN = 0
                    
                    playerstun = int(playerstun) - 1
                    if playerstun < 0:
                        playerstun = 0
                        
                    FIGHTCMD = raw_input("[COMBAT]: ")
                    
                    if playerstun > 0:
                        FIGHTCMD = 'stunD'
                    if FIGHTCMD == 'stunD':
                        print ('['+playername+'] is stunned!')
                    if FIGHTCMD == 'sk':
                        FIGHTCMD = 'skill'
                    if FIGHTCMD == 'skill':
                        if playerskills != []:
                            try:
                                playerskills.remove('')
                                playerskills.remove('')
                                playerskills.remove('')
                                playerskills.remove('')
                                playerskills.remove('')
                                playerskills.remove('')
                                playerskills.remove('')
                                playerskills.remove('')
                                playerskills.remove('')
                                playerskills.remove('')
                                
                            except:
                                pass
                            print playerskills
                            USESKILL = raw_input('['+playername+'] SKILL: ')
                            if USESKILL in playerskills: 
                                INSdata = ('C:\Realms\ITM\\'+USESKILL+ '.skl')
                                with open(INSdata) as f:
                                    content = f.readlines()
                                    content = [x.strip('\n') for x in content]
                                USEDESC = content[0]
                                EFFECTRECCUR = content[1]
                                EFFECT1 = content[2]
                                EFFECT1NUM = content[3]
                                EFFECT1DESC = content[4]
                                EFFECT2 = content[5]
                                EFFECT2NUM = content[6]
                                EFFECT2DESC = content[7]
                                EFFECT3 = content[8]
                                EFFECT3NUM = content[9]
                                EFFECT3DESC = content[10]
                                SKILLCOST = content[11]
                                CURRENTMOD = 'none'
                                CURRENTEFFECT = 0
                                print ('['+playername+'] MP: '+str(playermana))
                                print ('['+playername+'] COST: '+str(SKILLCOST))
                                global CURRENTEFFECT
                                CURRENTDESC = ''
        
                                    ##########  SKILL EFFECTS HERE ###########
                                    ## print ('[OPTIONS]: pierce, debuffatk, debuffdef, stun')
                                    ## print ('[OPTIONS]: playerhealhp, playerhealmp, none')
     
                                def EXECUTESKILL():
                                    PLACEHOLDER = 1
                                    if CURRENTMOD != 'none':
                                        print ('['+playername+'] ' + str(CURRENTDESC))
                                        if CURRENTMOD == 'pierce':
                                            global ENMHP
                                            global CURRENTEFFECT
                                            ENMHP = int(ENMHP) - int(CURRENTEFFECT)
                                            print ('['+TARGET+'] takes '+str(CURRENTEFFECT)+' damage!')
                                        if CURRENTMOD == 'debuffatk':
                                            global ENMATK
                                            global CURRENTEFFECT
                                            ENMATK = int(ENMATK) - int(CURRENTEFFECT)
                                            print ('['+TARGET+'] is weakened by '+str(CURRENTEFFECT)+'!')
                                        if CURRENTMOD == 'debuffdef':
                                            global ENMDEF
                                            global CURRENTEFFECT
                                            ENMDEF = int(ENMDEF) - int(CURRENTEFFECT)
                                            print ('['+TARGET+'] has lost '+str(CURRENTEFFECT)+' armor!')
                                        if CURRENTMOD == 'stun':
                                            global CURRENTEFFECT
                                            global ENMstun
                                            ENMstun = int(CURRENTEFFECT)
                                            print ('['+TARGET+'] is unable to attack for '+str(CURRENTEFFECT)+' turns!')
                                        if CURRENTMOD == 'healhp':
                                            global playerhealth
                                            global CURRENTEFFECT
                                            playerhealth = int(playerhealth) + int(CURRENTEFFECT)
                                            print ('['+playername+'] has recovered '+str(CURRENTEFFECT)+' HP!')
                                        if CURRENTMOD == 'selfharm':
                                            global playerhealth
                                            global CURRENTEFFECT
                                            playerhealth = int(playerhealth) - int(CURRENTEFFECT)
                                            print ('['+playername+'] has lost '+str(CURRENTEFFECT)+' HP!')
                                        if CURRENTMOD == 'playermp':
                                            global playermana
                                            global CURRENTEFFECT
                                            playermana = int(playermana) + int(CURRENTEFFECT)
                                            print ('['+playername+'] has recovered '+str(CURRENTEFFECT)+' MP!')
                                        if CURRENTMOD == 'atkboost':
                                            global PLAYERHIT
                                            global CURRENTEFFECT
                                            PLAYERHIT = int(PLAYERHIT) + int(CURRENTEFFECT)
                                            print ('['+playername+'] has gained '+str(CURRENTEFFECT)+' attack power!')
                                        if CURRENTMOD == 'defboost':
                                            global PLAYERSHIELD
                                            global CURRENTEFFECT
                                            PLAYERSHIELD = int(PLAYERSHIELD) + int(CURRENTEFFECT)
                                            print ('['+playername+'] has fortified defenses by '+str(CURRENTEFFECT)+' points!')

                                if int(playermana) >= int(SKILLCOST):
                                    playermana = int(playermana) - int(SKILLCOST)
                                    print ('['+playername+'] '+USEDESC)
                                    if int(EFFECTRECCUR) > 0:
                                        CURRENTMOD = str(EFFECT1)
                                        CURRENTEFFECT = int(EFFECT1NUM)
                                        CURRENTDESC =str(EFFECT1DESC)
                                        EXECUTESKILL()
                                    
                                    if int(EFFECTRECCUR) > 1:
                                        CURRENTMOD = str(EFFECT2)
                                        CURRENTEFFECT = int(EFFECT2NUM)
                                        CURRENTDESC =str(EFFECT2DESC)
                                        EXECUTESKILL()

                                    if int (EFFECTRECCUR) > 2:
                                        CURRENTMOD = str(EFFECT3)
                                        CURRENTEFFECT = int(EFFECT3NUM)
                                        CURRENTDESC =str(EFFECT3DESC)
                                        EXECUTESKILL()

                                else:
                                    print('['+str(playername)+'] I don\'t have enough energy.')
                                    SKIPTURN = 1

                                          
                            else:
                                print('['+str(playername)+'] I can\'t do that..')
                                SKIPTURN = 1
                                          
                        else:
                                print('['+str(playername)+'] I don\'t know any combat skills!')
                                SKIPTURN = 1


                            
                  
                                
                    if FIGHTCMD == 'help':
                        SKIPTURN = 1
                        print (' ')
                        print ('        [at] attack  =  Attack the enemy with your primary weapon')
                        print ('         [sk] skill  =  Use a combat skill. Requires MP')
                        print ('          [it] item  =  Use an item from your inventory')
                        print ('               wait  =  Do nothing. Not a great move')
                        print ('                run  =  Attempt to escape from combat')
                        print ('             ')

                    if FIGHTCMD == 'it':
                        FIGHTCMD = 'item'
                    if FIGHTCMD == 'item':
                        print playerinventory
                        USEITEM = raw_input('['+playername+'] ITEM:')
                        if USEITEM in playerinventory:
                            INSdata = ('C:\Realms\ITM\\'+USEITEM+ '.itm')
                            with open(INSdata) as f:
                                content = f.readlines()
                                content = [x.strip('\n') for x in content]
                            ITEMCLASS = content[0]
                            ITEMSTMOD = content[1]
                            ITEMSTNUM = content[2]
                            ITEMDESC = content[3]
                            ITEMDAM = content[4]
                            ITEMDEF = content[5]
                            ITEMKEY = content[6]
                            ITEMVAL = content[7]
                            
                            if ITEMCLASS == 'potion':
                                playerinventory.remove(USEITEM)
                                playerinvnumber = int(playerinvnumber)-1
                                print ('['+playername+'] You use the '+USEITEM+'.')
                                if ITEMSTMOD == 'teleport':
                                    print('['+str(playername)+'] It fizzles out..')
                                if ITEMSTMOD == 'playerstr':
                                    print('['+str(playername)+'] You feel like your muscles are growing..')
                                    playerstr = int(playerstr)+int(ITEMSTNUM)
                            
                                if ITEMSTMOD == 'playerluk':
                                    print('['+str(playername)+'] You feel like lady luck is smiling at you today.')
                                    playerluk = int(playerluk)+int(ITEMSTNUM)
                         
                                if ITEMSTMOD == 'playerdex':
                                    print('['+str(playername)+'] You feel swifter and more nimble.')
                                    playerdex = int(playerdex)+int(ITEMSTNUM)
                                
                                if ITEMSTMOD == 'playercha':
                                    print('['+str(playername)+'] You feel more suave than ever.')
                                    playercha = int(playercha)+int(ITEMSTNUM)
                                    
                                if ITEMSTMOD == 'playerint':
                                    print('['+str(playername)+'] You feel your conciousness expand..')
                                    playerint = int(playerint)+int(ITEMSTNUM)
                                   
                                if ITEMSTMOD == 'playercash':
                                    print('['+str(playername)+'] Your wallet feels hefty.')
                                    playercash = int(playercash)+int(ITEMSTNUM)
                      
                                if ITEMSTMOD == 'playerlvl':
                                    print('['+str(playername)+'] You feel more experienced.')
                                    playerexp = int(playerexp)+int(ITEMSTNUM)
                            
                                if ITEMSTMOD == 'playermaxhealth':
                                    print('['+str(playername)+'] You feel healthier than ever before.')
                                    playermaxhealth = int(playermaxhealth)+int(ITEMSTNUM)
                                    playerhealth = playermaxhealth
                           
                                if ITEMSTMOD == 'playerhealth':
                                    print('['+str(playername)+'] You feel revitalized and renewed!')
                                    playerhealth = int(playerhealth)+int(ITEMSTNUM)
                                    
                                if ITEMSTMOD == 'bagexpand':
                                    print('['+str(playername)+'] Your bag can now hold more items.')
                                    playerinvlimit = int(ITEMSTNUM)
                                    
                                if ITEMSTMOD == 'playermana':
                                    print('['+str(playername)+'] You feel refreshed and energized!.')
                                    playermana = int(playermana)+int(ITEMSTNUM)

                                if ITEMSTMOD == 'playermaxmana':
                                    print('['+str(playername)+'] You feel revitalized and renewed!')
                                    playermaxmana= int(playermaxmana)+int(ITEMSTNUM)
                                    playermana = playermaxmana
    
                            if ITEMCLASS == 'item':
                                playerinventory.remove(USEITEM)
                                playerinvnumber = int(playerinvnumber)-1
                                DEFCHECK = (int(ITEMDAM)+(int(playerdex)*1.2))
                                DEFCHECK = (int(DEFCHECK)-int(ENMDEF))
                                if int(DEFCHECK) < 0:
                                    DEFCHECK = 0
                                ENMHP = int(ENMHP)-int(DEFCHECK)
                                if DEFCHECK == 0:
                                    print ('['+playername+'] Your throw connects, but it does no damage! ')
                                else:
                                    print ('['+playername+'] You heave your '+USEITEM+' at the '+TARGET+'!')
                                    print ('['+playername+'] A direct hit! The '+USEITEM+' deals '+str(DEFCHECK)+' damage!')    
                        else:
                            print ('['+playername+'] I have no such item!')
                            SKIPTURN = 1
                    if FIGHTCMD == 'run':
                        RUNCHANCE = randint(1,100)
                        RUNCHANCE = int(RUNCHANCE)-int(playerdex)
                        if RUNCHANCE < 50:
                            print ('['+playername+'] you manage to escape!')
                            SKIPTURN = 1
                            FIGHTSKIP = 1
                            MELOFF2()
                        else:
                            print ('['+playername+'] Couldn\'t get away!')
                    if FIGHTCMD == 'at':
                        FIGHTCMD = 'attack'
                    if FIGHTCMD == 'attack':
                        SKIPTURN = 0
                        ATTACKTEXT = randint(1,5)
                        if ATTACKTEXT == 1:
                            print ('['+playername+'] '+str(PLAYERATK1))
                        if ATTACKTEXT == 2:
                            print ('['+playername+'] '+str(PLAYERATK2))
                        if ATTACKTEXT == 3:
                            print ('['+playername+'] '+str(PLAYERATK3))
                        if ATTACKTEXT == 4:
                            print ('['+playername+'] '+str(PLAYERATK4))
                        if ATTACKTEXT == 5:
                            print ('['+playername+'] '+str(PLAYERATK5))
                            
                        ##### DAMAGE ALGORITHM #####
                        REALDAMAGE = int(PLAYERHIT) * int(playerstr)
  
                        DEXMOD = int(playerdex)+1
                        DEXMOD = int(DEXMOD)/2
                        REALDAMAGE = int(REALDAMAGE) + int(DEXMOD)

                        LUKMOD = randint(0,5) * int(playerluk)
                        REALDAMAGE = int(REALDAMAGE) + int(LUKMOD)
                                #######################
                        DEFCHECK = REALDAMAGE
                        DEFCHECK = (int(DEFCHECK)-int(ENMDEF))

                        ####PIERCE CHECK#######

                        SOULWEP = str(playerwep)
                        if playerwep != 'empty':
                            INSdata = ('C:\Realms\ITM\\'+str(playerwep)+ '.itm')
                            with open(INSdata) as f:
                                content = f.readlines()
                                content = [x.strip('\n') for x in content]
                            ITEMCLASS = content[0]
                            ITEMSTMOD = content[1]
                            ITEMSTNUM = content[2]
                            ITEMDESC = content[3]
                            ITEMDAM = content[4]
                            ITEMDEF = content[5]
                            ITEMKEY = content[6]
                            ITEMVAL = content[7]
                        else:
                            ITEMSTMOD = 'none'
                        if ITEMSTMOD == 'pierce':
                            NEWDAM = int(DEFCHECK) + int(ITEMSTNUM)
                            DEFCHECK = NEWDAM


                        if int(DEFCHECK) < 0:
                            DEFCHECK = 0
                        else:
                            pass
                        
                        ENMHP = int(ENMHP)-int(DEFCHECK)

                        ########HEALTHLEECH CHECK#######
                        if ITEMSTMOD == 'healthleech':
          
                            LEECHNUM = int(ITEMSTNUM)
                            DEFCHECK = int(DEFCHECK)
                            if DEFCHECK > LEECHNUM:
                                playerhealth = int(playerhealth) + int(LEECHNUM)
                                LEECHNUM = int(LEECHNUM)
                            else:
                                LEECHNUM = int(DEFCHECK)
                                playerhealth = int(playerhealth) + int(LEECHNUM)
                                LEECHNUM = int(LEECHNUM)
                        else:
                            pass
                        ################################
                        ########HEALTHLEECH CHECK#######

                        if ITEMSTMOD == 'manaleech':
          
                            LEECHNUM = int(ITEMSTNUM)
                            DEFCHECK = int(DEFCHECK)
                            if DEFCHECK > LEECHNUM:
                                playermana = int(playermana) + int(LEECHNUM)
                                LEECHNUM = int(LEECHNUM)
                            else:
                                LEECHNUM = int(DEFCHECK)
                                playermana = int(playermana) + int(LEECHNUM)
                                LEECHNUM = int(LEECHNUM)
                        else:
                            pass
                        ################################
                        
                        if DEFCHECK == 0:
                            print ('['+playername+'] you do no damage... ')
                        else:
                            print ('['+playername+'] you land an attack for '+str(DEFCHECK)+' damage!')
                            
                            if ITEMSTMOD == 'healthleech' and LEECHNUM > 0:
                                print ('['+playername+'] Your '+str(playerwep)+' absorbs '+str(LEECHNUM)+' HP!')
                            if ITEMSTMOD == 'manaleech' and LEECHNUM > 0:
                                print ('['+playername+'] Your '+str(playerwep)+' absorbs '+str(LEECHNUM)+' MP!')
                            ATTACKTEXT = randint(1,5)
                            if ATTACKTEXT == 1:
                                print ('['+TARGET+'] '+str(ENMDEF1))
                            if ATTACKTEXT == 2:
                                print ('['+TARGET+'] '+str(ENMDEF2))
                            if ATTACKTEXT == 3:
                                print ('['+TARGET+'] '+str(ENMDEF3))
                            if ATTACKTEXT == 4:
                                print ('['+TARGET+'] '+str(ENMDEF4))
                            if ATTACKTEXT == 5:
                                print ('['+TARGET+'] '+str(ENMDEF5))
              
    
            ###### VALID MOVE CHECKER ############################################
                    VALIDMOVES = ['attack','item','help','run','skill','stunD','wait']
                    if FIGHTCMD in VALIDMOVES and SKIPTURN == 0:


            ####### COMPANION ATTACK PHASE ########
                        if playercomp != 'none':
                            
                            compandata = ('C:\\Realms\\NPC\\'+str(playercomp)+'.npc')
                            with open(compandata) as f:
                                compdat = f.readlines()
                                compdat = [x.strip('\n') for x in compdat]
                            compatk = compdat[0]
                            compdef = compdat[1]
                            compinvcap = compdat[2]
                            compidle = compdat[3]
                            comphire = compdat[4]
                            compfire = compdat[5]
                            comphp  = compdat[6]
                            compmaxhp = compdat[7]
                            comphealskill = compdat[8]
                            compheallim = compdat[9]
                            compatkskill = compdat[10]
                            compatkchance = compdat[11]
                            compatk1 = compdat[12]
                            compatk2 = compdat[13]
                            compatk3 = compdat[14]
                            compatk4 = compdat[15]
                            compatk5 = compdat[16]
                            if int(playerhealth) <= int(compheallim) and comphealskill != 'none':
                                INSdata = ('C:\Realms\ITM\\'+comphealskill+ '.skl')
                                content = []
                                with open(INSdata) as f:
                                    content = f.readlines()
                                    content = [x.strip('\n') for x in content]
                                USEDESC = content[0]
                                EFFECTRECCUR = content[1]
                                EFFECT1 = content[2]
                                EFFECT1NUM = content[3]
                                EFFECT1DESC = content[4]
                                EFFECT2 = content[5]
                                EFFECT2NUM = content[6]
                                EFFECT2DESC = content[7]
                                EFFECT3 = content[8]
                                EFFECT3NUM = content[9]
                                EFFECT3DESC = content[10]
                                SKILLCOST = content[11]
                                CURRENTMOD = 'none'
                                CURRENTEFFECT = 0
                                global CURRENTEFFECT
                                CURRENTDESC = ''
                                
                                def COMPEXECUTESKILL():
                                    PLACEHOLDER = 1
                                    if CURRENTMOD != 'none':
                                        print ('['+playername+'] ' + str(CURRENTDESC))
                                        if CURRENTMOD == 'pierce':
                                            global ENMHP
                                            global CURRENTEFFECT
                                            ENMHP = int(ENMHP) - int(CURRENTEFFECT)
                                            print ('['+TARGET+'] takes '+str(CURRENTEFFECT)+' damage!')
                                        if CURRENTMOD == 'debuffatk':
                                            global ENMATK
                                            global CURRENTEFFECT
                                            ENMATK = int(ENMATK) - int(CURRENTEFFECT)
                                            print ('['+TARGET+'] is weakened by '+str(CURRENTEFFECT)+'!')
                                        if CURRENTMOD == 'debuffdef':
                                            global ENMDEF
                                            global CURRENTEFFECT
                                            ENMDEF = int(ENMDEF) - int(CURRENTEFFECT)
                                            print ('['+TARGET+'] has lost '+str(CURRENTEFFECT)+' armor!')
                                        if CURRENTMOD == 'stun':
                                            global CURRENTEFFECT
                                            global ENMstun
                                            ENMstun = int(CURRENTEFFECT)
                                            print ('['+TARGET+'] is unable to attack for '+str(CURRENTEFFECT)+' turns!')
                                        if CURRENTMOD == 'healhp':
                                            global playerhealth
                                            global CURRENTEFFECT
                                            playerhealth = int(playerhealth) + int(CURRENTEFFECT)
                                            print ('['+playername+'] has recovered '+str(CURRENTEFFECT)+' HP!')
                                        if CURRENTMOD == 'selfharm':
                                            global playerhealth
                                            global CURRENTEFFECT
                                            playerhealth = int(playerhealth) - int(CURRENTEFFECT)
                                            print ('['+playername+'] has lost '+str(CURRENTEFFECT)+' HP!')
                                        if CURRENTMOD == 'playermp':
                                            global playermana
                                            global CURRENTEFFECT
                                            playermana = int(playermana) + int(CURRENTEFFECT)
                                            print ('['+playername+'] has recovered '+str(CURRENTEFFECT)+' MP!')
                                        if CURRENTMOD == 'atkboost':
                                            global PLAYERHIT
                                            global CURRENTEFFECT
                                            PLAYERHIT = int(PLAYERHIT) + int(CURRENTEFFECT)
                                            print ('['+playername+'] has gained '+str(CURRENTEFFECT)+' attack power!')
                                        if CURRENTMOD == 'defboost':
                                            global PLAYERSHIELD
                                            global CURRENTEFFECT
                                            PLAYERSHIELD = int(PLAYERSHIELD) + int(CURRENTEFFECT)
                                            print ('['+playername+'] has fortified defenses by '+str(CURRENTEFFECT)+' points!')

                                print ('['+playercomp+'] '+USEDESC)            
                                if int(EFFECTRECCUR) > 0:
                                    CURRENTMOD = str(EFFECT1)
                                    CURRENTEFFECT = int(EFFECT1NUM)
                                    CURRENTDESC =str(EFFECT1DESC)
                                    COMPEXECUTESKILL()
                                    
                                if int(EFFECTRECCUR) > 1:
                                    CURRENTMOD = str(EFFECT2)
                                    CURRENTEFFECT = int(EFFECT2NUM)
                                    CURRENTDESC =str(EFFECT2DESC)
                                    COMPEXECUTESKILL()

                                if int (EFFECTRECCUR) > 2:
                                    CURRENTMOD = str(EFFECT3)
                                    CURRENTEFFECT = int(EFFECT3NUM)
                                    CURRENTDESC =str(EFFECT3DESC)
                                    COMPEXECUTESKILL()
                                SKILLHAPPEN = 1
                            else:
                                SKILLHAPPEN = 0
                            if SKILLHAPPEN == 0:
                                ATKSKILLCHANCE = randint(1,100)
                                if compatkskill != 'none' and int(ATKSKILLCHANCE) < int(compatkchance) :
                                    INSdata = ('C:\Realms\ITM\\'+compatkskill+ '.skl')
                                    content = []
                                    with open(INSdata) as f:
                                        content = f.readlines()
                                        content = [x.strip('\n') for x in content]
                                    USEDESC = content[0]
                                    EFFECTRECCUR = content[1]
                                    EFFECT1 = content[2]
                                    EFFECT1NUM = content[3]
                                    EFFECT1DESC = content[4]
                                    EFFECT2 = content[5]
                                    EFFECT2NUM = content[6]
                                    EFFECT2DESC = content[7]
                                    EFFECT3 = content[8]
                                    EFFECT3NUM = content[9]
                                    EFFECT3DESC = content[10]
                                    SKILLCOST = content[11]
                                    CURRENTMOD = 'none'
                                    CURRENTEFFECT = 0
                                    global CURRENTEFFECT
                                    CURRENTDESC = ''
                                    def COMPEXECUTESKILL():
                                        PLACEHOLDER = 1
                                        if CURRENTMOD != 'none':
                                            print ('['+playername+'] ' + str(CURRENTDESC))
                                            if CURRENTMOD == 'pierce':
                                                global ENMHP
                                                global CURRENTEFFECT
                                                ENMHP = int(ENMHP) - int(CURRENTEFFECT)
                                                print ('['+TARGET+'] takes '+str(CURRENTEFFECT)+' damage!')
                                            if CURRENTMOD == 'debuffatk':
                                                global ENMATK
                                                global CURRENTEFFECT
                                                ENMATK = int(ENMATK) - int(CURRENTEFFECT)
                                                print ('['+TARGET+'] is weakened by '+str(CURRENTEFFECT)+'!')
                                            if CURRENTMOD == 'debuffdef':
                                                global ENMDEF
                                                global CURRENTEFFECT
                                                ENMDEF = int(ENMDEF) - int(CURRENTEFFECT)
                                                print ('['+TARGET+'] has lost '+str(CURRENTEFFECT)+' armor!')
                                            if CURRENTMOD == 'stun':
                                                global CURRENTEFFECT
                                                global ENMstun
                                                ENMstun = int(CURRENTEFFECT)
                                                print ('['+TARGET+'] is unable to attack for '+str(CURRENTEFFECT)+' turns!')
                                            if CURRENTMOD == 'healhp':
                                                global playerhealth
                                                global CURRENTEFFECT
                                                playerhealth = int(playerhealth) + int(CURRENTEFFECT)
                                                print ('['+playername+'] has recovered '+str(CURRENTEFFECT)+' HP!')
                                            if CURRENTMOD == 'selfharm':
                                                global playerhealth
                                                global CURRENTEFFECT
                                                playerhealth = int(playerhealth) - int(CURRENTEFFECT)
                                                print ('['+playername+'] has lost '+str(CURRENTEFFECT)+' HP!')
                                            if CURRENTMOD == 'playermp':
                                                global playermana
                                                global CURRENTEFFECT
                                                playermana = int(playermana) + int(CURRENTEFFECT)
                                                print ('['+playername+'] has recovered '+str(CURRENTEFFECT)+' MP!')
                                            if CURRENTMOD == 'atkboost':
                                                global PLAYERHIT
                                                global CURRENTEFFECT
                                                PLAYERHIT = int(PLAYERHIT) + int(CURRENTEFFECT)
                                                print ('['+playername+'] has gained '+str(CURRENTEFFECT)+' attack power!')
                                            if CURRENTMOD == 'defboost':
                                                global PLAYERSHIELD
                                                global CURRENTEFFECT
                                                PLAYERSHIELD = int(PLAYERSHIELD) + int(CURRENTEFFECT)
                                                print ('['+playername+'] has fortified defenses by '+str(CURRENTEFFECT)+' points!')
    
                                    print ('['+playercomp+'] '+USEDESC)            
                                    if int(EFFECTRECCUR) > 0:
                                        CURRENTMOD = str(EFFECT1)
                                        CURRENTEFFECT = int(EFFECT1NUM)
                                        CURRENTDESC =str(EFFECT1DESC)
                                        COMPEXECUTESKILL()
                                        
                                    if int(EFFECTRECCUR) > 1:
                                        CURRENTMOD = str(EFFECT2)
                                        CURRENTEFFECT = int(EFFECT2NUM)
                                        CURRENTDESC =str(EFFECT2DESC)
                                        COMPEXECUTESKILL()
    
                                    if int (EFFECTRECCUR) > 2:
                                        CURRENTMOD = str(EFFECT3)
                                        CURRENTEFFECT = int(EFFECT3NUM)
                                        CURRENTDESC =str(EFFECT3DESC)
                                        COMPEXECUTESKILL()  
                                else:
                                        
                                    ATTACKTEXT = randint(1,5)
                                        
                                    if ATTACKTEXT == 1:
                                        print ('['+playercomp+'] '+str(compatk1))
                                    if ATTACKTEXT == 2:
                                        print ('['+playercomp+'] '+str(compatk2))
                                    if ATTACKTEXT == 3:
                                        print ('['+playercomp+'] '+str(compatk3))
                                    if ATTACKTEXT == 4:
                                        print ('['+playercomp+'] '+str(compatk4))
                                    if ATTACKTEXT == 5:
                                        print ('['+playercomp+'] '+str(compatk5))
    
                                    DEFCHECK = (int(compatk)-int(ENMDEF))
                                    if int(DEFCHECK) < 0:
                                        DEFCHECK = 0
                                    ENMHP = int(ENMHP)-int(DEFCHECK)
                                    if DEFCHECK == 0:
                                        print ('['+playercomp+'] does no damage! ')
                                    else:
                                        print ('['+playercomp+'] lands an attack for '+str(DEFCHECK)+' damage!')
                            else:
                                pass




                        #######BEGIN STUNCHECK #########
                        MISSCHANCE = int(playerdex)*1.5
                        MISSROLL = randint(0,100)
                        if int(ENMHP) > 0:

                            #ENMSKILLCHANCE = enemyi[15]
                            #ENMSKILL = enemyi[16]
                            SKILLROLL = randint(0,100)
                            if SKILLROLL <= int(ENMSKILLCHANCE) and ENMSKILL != 'none':
                                
                       #############   ENEMY SKILL CAST GOES HERE  ###############3#
                                
                                INSdata = ('C:\Realms\ITM\\'+ENMSKILL+ '.skl')
                                with open(INSdata) as f:
                                    content = f.readlines()
                                    content = [x.strip('\n') for x in content]
                                USEDESC = content[0]
                                EFFECTRECCUR = content[1]
                                EFFECT1 = content[2]
                                EFFECT1NUM = content[3]
                                EFFECT1DESC = content[4]
                                EFFECT2 = content[5]
                                EFFECT2NUM = content[6]
                                EFFECT2DESC = content[7]
                                EFFECT3 = content[8]
                                EFFECT3NUM = content[9]
                                EFFECT3DESC = content[10]
                                SKILLCOST = content[11]
                                CURRENTMOD = 'none'
                                CURRENTEFFECT = 0
                                global CURRENTEFFECT
                                CURRENTDESC = ''
                                
                                def ENEMYEXECUTESKILL():
                                    PLACEHOLDER = 1
                                    if CURRENTMOD != 'none':
                                        print ('['+TARGET+'] ' + str(CURRENTDESC))
                                        if CURRENTMOD == 'pierce':
                                            global playerhealth
                                            global CURRENTEFFECT
                                            playerhealth = int(playerhealth) - int(CURRENTEFFECT)
                                            print ('['+playername+'] takes '+str(CURRENTEFFECT)+' damage!')
                                        if CURRENTMOD == 'debuffatk':
                                            global PLAYERHIT
                                            global CURRENTEFFECT
                                            PLAYERHIT = int(PLAYERHIT) - int(CURRENTEFFECT)
                                            print ('['+playername+'] is weakened by '+str(CURRENTEFFECT)+'!')
                                        if CURRENTMOD == 'debuffdef':
                                            global PLAYERSHIELD
                                            global CURRENTEFFECT
                                            PLAYERSHIELD = int(PLAYERSHIELD) - int(CURRENTEFFECT)
                                            print ('['+playername+'] has lost '+str(CURRENTEFFECT)+' armor!')
                                        if CURRENTMOD == 'stun':
                                            global CURRENTEFFECT
                                            global playerstun
                                            playerstun = int(CURRENTEFFECT)
                                            print ('['+playername+'] is unable to attack for '+str(CURRENTEFFECT)+' turns!')
                                        if CURRENTMOD == 'healhp':
                                            global ENMHP
                                            global CURRENTEFFECT
                                            ENMHP = int(ENMHP) + int(CURRENTEFFECT)
                                            print ('['+TARGET+'] has recovered '+str(CURRENTEFFECT)+' HP!')
                                        if CURRENTMOD == 'selfharm':
                                            global ENMHP
                                            global CURRENTEFFECT
                                            ENMHP = int(ENMHP) - int(CURRENTEFFECT)
                                            print ('['+TARGET+'] has lost '+str(CURRENTEFFECT)+' HP!')
                                        if CURRENTMOD == 'playermp':
                                            global playermana
                                            global CURRENTEFFECT
                                            playermana = int(playermana) - int(CURRENTEFFECT)
                                            print ('['+playername+'] has been drained of '+str(CURRENTEFFECT)+' MP!')
                                        if CURRENTMOD == 'atkboost':
                                            global ENMATK
                                            global CURRENTEFFECT
                                            ENMATK = int(ENMATK) + int(CURRENTEFFECT)
                                            print ('['+TARGET+'] has gained '+str(CURRENTEFFECT)+' attack power!')
                                        if CURRENTMOD == 'defboost':
                                            global ENMDEF
                                            global CURRENTEFFECT
                                            ENMDEF = int(ENMDEF) + int(CURRENTEFFECT)
                                            print ('['+TARGET+'] has fortified defenses by '+str(CURRENTEFFECT)+' points!')
                                print ('['+TARGET+'] '+USEDESC)            
                                if int(EFFECTRECCUR) > 0:
                                    CURRENTMOD = str(EFFECT1)
                                    CURRENTEFFECT = int(EFFECT1NUM)
                                    CURRENTDESC =str(EFFECT1DESC)
                                    ENEMYEXECUTESKILL()
                                    
                                if int(EFFECTRECCUR) > 1:
                                    CURRENTMOD = str(EFFECT2)
                                    CURRENTEFFECT = int(EFFECT2NUM)
                                    CURRENTDESC =str(EFFECT2DESC)
                                    ENEMYEXECUTESKILL()

                                if int (EFFECTRECCUR) > 2:
                                    CURRENTMOD = str(EFFECT3)
                                    CURRENTEFFECT = int(EFFECT3NUM)
                                    CURRENTDESC =str(EFFECT3DESC)
                                    ENEMYEXECUTESKILL()
                                    

                                SKILLHAPPEN = 1
                            else:
                                SKILLHAPPEN = 0
                            if SKILLHAPPEN == 0:
                                
                                if int(MISSROLL) < int(MISSCHANCE):
                                    print ('['+TARGET+'] attacks, but you evade!')
                                elif ENMstun > 0:
                                    print ('['+TARGET+'] Can\'t attack!')
                                else:
                                    ATTACKTEXT = randint(1,5)
                                    
                                    if ATTACKTEXT == 1:
                                        print ('['+TARGET+'] '+str(ENMATK1))
                                    if ATTACKTEXT == 2:
                                        print ('['+TARGET+'] '+str(ENMATK2))
                                    if ATTACKTEXT == 3:
                                        print ('['+TARGET+'] '+str(ENMATK3))
                                    if ATTACKTEXT == 4:
                                        print ('['+TARGET+'] '+str(ENMATK4))
                                    if ATTACKTEXT == 5:
                                        print ('['+TARGET+'] '+str(ENMATK5))

                                    DEFCHECK = (int(ENMATK)-int(PLAYERSHIELD))
                                    if int(DEFCHECK) < 0:
                                        DEFCHECK = 0
                                    playerhealth = int(playerhealth)-int(DEFCHECK)
                                    if DEFCHECK == 0:
                                        print ('['+TARGET+'] does no damage! ')
                                    else:
                                        print ('['+TARGET+'] lands an attack for '+str(DEFCHECK)+' damage!')
                            else:
                                pass
                            print (' ')
                            playerhealth = int(playerhealth)
                            playermaxhealth = int(playermaxhealth)
                            if playerhealth > playermaxhealth:
                                 playerhealth = playermaxhealth
                            if playerhealth < 0:
                                playerhealth = 0
                            if playermana < 0:
                                playermana = 0
                            print ('['+playername+']HP:' + str(playerhealth)+'  MP:'+str(playermana)+'             ['+TARGET+']HP:' + str(ENMHP))
                            print (' ')
                        if int(playerhealth)<1:
                            print (' ')
                            print (' ')
                            print ('                '+playername+' has died.')
                            print (' ')
                            print (' ')
                            print (' ')
                            print (' ')
                            print (' ')
                            print (' ')
                            MELOFF2()
                            BoolFalse()
                        if int(ENMHP)<1:
                            print ('['+TARGET+'] has been vanquished. '+ ENMEXP +' experience gained!')
                            ###SOULEDGE CHECK##
                            if playerwep != 'empty':
                                SOULWEP = str(playerwep)
                                INSdata = ('C:\Realms\ITM\\'+str(playerwep)+ '.itm')
                                with open(INSdata) as f:
                                    content = f.readlines()
                                    content = [x.strip('\n') for x in content]
                                ITEMCLASS = content[0]
                                ITEMSTMOD = content[1]
                                ITEMSTNUM = content[2]
                                ITEMDESC = content[3]
                                ITEMDAM = content[4]
                                ITEMDEF = content[5]
                                ITEMKEY = content[6]
                                ITEMVAL = content[7]
                            else:
                                ITEMSTMOD = 'none'
                            if ITEMSTMOD == 'souledge':
                                print ('['+playername+'] Your '+playerwep+' grows in power!')
                                ITEMDAM = int(ITEMDAM) + int(ITEMSTNUM)
                                playerdam = int(playerdam) + int(ITEMSTNUM)
                                content[4] = str(ITEMDAM)
                                WEAPONMOD = str(playerwep)
                                open('C:\\Realms\\ITM\\'+WEAPONMOD+'.itm', "w").close()
                                with open('C:\\Realms\\ITM\\'+WEAPONMOD+'.itm', "w") as f:
                                    for s in content:
                                        f.write(s + '\n') 
                            #####

                            if ENMDROP != 'none':
                                print ('['+TARGET+'] has dropped a '+str(ENMDROP)+'!')
                                localinventory.insert(0,ENMDROP)
                                
                            print (' ')
                            playerexp = (int(playerexp)+int(ENMEXP))
                            enemy.remove(TARGET)
                            open('C:\\Realms\\INV\\'+str(playerX)+' '+str(playerY)+'.enm', "w").close()
                            with open('C:\\Realms\\INV\\'+str(playerX)+' '+str(playerY)+'.enm', "w") as f:
                                for s in enemy:
                                    f.write(s + '\n')
                                    
                            MELOFF2()
                    else:
                        pass
            except:
                pass
    
                    
                
    ###############################GENERAL EXCEPTITON HANDLER#######################