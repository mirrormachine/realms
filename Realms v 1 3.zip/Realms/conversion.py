from distutils.core import setup
import py2exe , sys, os
 
setup(
    options = {'py2exe': {'bundle_files': 1}},
 
    console = [{'script': "Realms.py"}],
    zipfile = None,
)
