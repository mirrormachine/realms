

	Realms engine by Julian Bintner
	-=-=-=-=-=-=-=-=-=-=-=-=-=-=
	This is a free and open source
	game. Feel free to distribute.
	-=-=-=-=-=-=-=-=-=-=-=-=-=-=


		TO INSTALL=-

	Place the included 'realms'
	folder in the C drive.



		TO PLAY=-

	If you want to jump right in,
	run realms.exe.


	   CONTENT CREATION=-

	use the 'god' command 
	with a character loaded 
	in game, if you want to
	access the content editor,
	which is what I used to
	create the included demo
	world, FLUX. The creator
	console can create every
	element of gameplay and it
	walks you through exactly
	how to do it. use 'help'.

	However,
	you CAN modify the source
	code and experiment if you
	are so inclined. You need
	to set up a python development
	environment. The source code
	is included in the file
	'realms.py'.
	
	If you have a python editor
	installed, you can run the			game directly through the 			source code with the
	'runfromsource.bat' file
	included, useful if you 
	want to mod the game.
	
	When your mod is done, use
	export2exe.bat to convert
	the source code to a new exe
	file.
